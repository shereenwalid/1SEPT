"""
================================================================================
 VALIDATION AGENT - self-contained single file
================================================================================
Everything the validation agent needs in ONE module: config constants, the
proxy-backed Gemini model, all five tools (with their helpers), the full
VALIDATION_PROMPT, and the agent definition.

ROLE
----
The quality-gate of the quote-to-order pipeline. Given an OPPORTUNITY ID it:
  1. Retrieves the opportunity's parsed documents from GCS (get_opportunity_data).
  2. Determines the ORDER CATEGORY (Kit / Circuit / other) from the VBOP file.
  3. Runs the checks and emits a Y/N JSON report:
       - Required Information  R1-R7
       - Document Validation   C1-C27
       - BSP base checks       B1-B13   (all order types; B13 = billing address)
       - Circuit checks        X1-X9    (Circuit only)
     using BigQuery lookups (lookup_bsp_company / lookup_bsp_location) for the
     BSP checks.
  4. Suggests an action owner for each failed check.
  5. Preserves human feedback across re-runs.
  6. Never blocks the pipeline (errors -> full JSON, all "N", problem explained).
Output -> session state key "validation_report".

TOOLS
-----
  get_opportunity_data, lookup_bsp_company, lookup_bsp_location,
  save_validation_status, get_validation_status

To run standalone you still need: google-adk, google-genai,
google-cloud-storage, google-cloud-bigquery, google-cloud-aiplatform, and
valid GCP credentials + the LLM proxy reachable.
================================================================================
"""

import os
import re
import json
import difflib
from datetime import date, datetime

from google.cloud import storage
from google import genai
import google.oauth2.id_token
from google.cloud import aiplatform
from google.genai.types import HttpOptions
from google.adk import Agent
from google.adk.models import Gemini
from google.adk.tools import ToolContext


# ─────────────────────────────────────────────────────────────────────
# CONFIG (inlined from Agent/config.py)
# ─────────────────────────────────────────────────────────────────────
PROJECT_ID = os.getenv("GCP_PROJECT_ID", "vf-ie-aib-prd-iei-cfa-lab")
REGION = os.getenv("GCP_REGION", "europe-west1")
LLM_PROXY_ENDPOINT = os.getenv(
    "LLM_PROXY_ENDPOINT",
    "https://proxy-service-1034231601515.europe-west1.run.app",
)

## Full GCS path to the folder containing one subfolder per opportunity id.
## Examples:
##   gs://vfie-dh-customer-fixed
##   gs://vfie-dh-customer-fixed/parsed/opportunities
GCS_BASE_PATH = os.getenv("GCS_BASE_PATH", "gs://vfie-dh-customer-fixed")


def _parse_gcs_path(path: str) -> tuple[str, str]:
    """Split 'gs://bucket/optional/prefix' into (bucket, prefix)."""
    path = path.strip().removeprefix("gs://").strip("/")
    bucket, _, prefix = path.partition("/")
    return bucket, prefix


GCS_BUCKET_NAME, GCS_BASE_PREFIX = _parse_gcs_path(GCS_BASE_PATH)

# BigQuery (BSP internal validation) - direct access via google-cloud-bigquery
BQ_PROJECT = os.getenv("BQ_PROJECT", "vf-ie-aib-prd-iei-cfa-lab")
BQ_DATASET = os.getenv(
    "BQ_DATASET",
    "vf-ie-datahub.vfie_dh_lake_customer_complex_fixed_s",
)

# ─────────────────────────────────────────────────────────────────────
# MODEL: proxy-backed Gemini (inlined from Agent/agent.py)
# ─────────────────────────────────────────────────────────────────────
aiplatform.init(project=PROJECT_ID, location=REGION)

api_endpoint = f"{LLM_PROXY_ENDPOINT}/google-llm"
id_creds = google.oauth2.id_token.fetch_id_token_credentials(LLM_PROXY_ENDPOINT)

client = genai.Client(
    vertexai=True,
    location=REGION,
    project=PROJECT_ID,
    credentials=id_creds,
    http_options=HttpOptions(base_url=api_endpoint, api_version="v1beta1"),
)

gemini_model = Gemini(model="gemini-2.5-pro")
gemini_model.api_client = client

# ─────────────────────────────────────────────────────────────────────
# TOOLS + HELPERS (inlined from Agent/tools.py)
# ─────────────────────────────────────────────────────────────────────


# Per-document size budgets. Defined here (env-overridable) so tools.py never
# fails to import when an older config.py lacks these names. If your config.py
# defines them they still win via the environment / its own module, but tools
# no longer *imports* them, so a missing name can't break the agent.
MAX_DOC_CHARS = int(os.getenv("MAX_DOC_CHARS", "40000"))
MAX_TOTAL_DOC_CHARS = int(os.getenv("MAX_TOTAL_DOC_CHARS", "120000"))
MAX_TECHSPEC_CHARS = int(os.getenv("MAX_TECHSPEC_CHARS", "60000"))

STATUS_FILENAME = "validation_status.json"

# Keys like "unnamed_01", "unnamed: 12", "Unnamed_3" are empty spreadsheet
# columns emitted by the parser. When their value is empty they carry no
# validation value and can bloat a parsed file to hundreds of MB, so we drop
# them at ingestion. Non-empty unnamed_* values are KEPT (they may hold real
# data under a missing header).
_UNNAMED_RE = re.compile(
    r"^\s*(?:unnamed|__?empty|column|col|field|var|x)?[\s_:\-\.]*\d+\s*$",
    re.IGNORECASE,
)


def _is_empty(v) -> bool:
    if v is None:
        return True
    if isinstance(v, str) and v.strip().lower() in ("", "null", "none", "nan", "n/a"):
        return True
    if isinstance(v, list):
        return all(_is_empty(x) for x in v)
    if isinstance(v, dict):
        return all(_is_empty(x) for x in v.values())
    return False


def _prune_empty(obj):
    """Recursively remove empty 'unnamed_*' keys and drop empty rows.

    Returns (cleaned_obj, removed_count). Real data is never removed - only
    keys whose name is an unnamed placeholder AND whose value is empty, plus
    fully-empty dict/list entries left behind.
    """
    removed = 0

    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _UNNAMED_RE.match(str(k)) and _is_empty(v):
                removed += 1
                continue
            cleaned, r = _prune_empty(v)
            removed += r
            # drop a key that became empty only if it was an unnamed placeholder
            if _UNNAMED_RE.match(str(k)) and _is_empty(cleaned):
                removed += 1
                continue
            out[k] = cleaned
        return out, removed

    if isinstance(obj, list):
        out_list = []
        for item in obj:
            cleaned, r = _prune_empty(item)
            removed += r
            # drop rows that are entirely empty after pruning
            if _is_empty(cleaned):
                removed += 1
                continue
            out_list.append(cleaned)
        return out_list, removed

    return obj, removed


# ─────────────────────────────────────────────────────────────────────
# Deterministic size-budgeting so the payload never exceeds the model cap
# ─────────────────────────────────────────────────────────────────────
# Total character budget for ALL documents combined that we hand to an agent.
# The model rejects oversized inputs ("constraint is too tall"); this keeps
# us safely under it. Tune via env if the proxy cap changes.
# Default total character budget for ALL documents combined. Kept low and
# safe; the API can shrink it further per-run via the CONDENSE_TOTAL_BUDGET
# env var and retry until the model accepts the input.
_CONDENSE_DEFAULT = 120000


def _condense_budget() -> int:
    # read live each call so a retry can lower it without a restart
    return int(os.getenv("CONDENSE_TOTAL_BUDGET", str(_CONDENSE_DEFAULT)))


CONDENSE_TOTAL_BUDGET = _condense_budget()
# Per-document ceiling for NON priority docs (tech spec / VBOP get more).
CONDENSE_PER_DOC_BUDGET = int(os.getenv("CONDENSE_PER_DOC_BUDGET", "40000"))
# Clip individual string values longer than this.
CONDENSE_MAX_STR = int(os.getenv("CONDENSE_MAX_STR", "2000"))
# Cap how many rows we keep from a huge array of records.
CONDENSE_MAX_ROWS = int(os.getenv("CONDENSE_MAX_ROWS", "400"))


def _clip_strings(obj, max_str):
    """Clip over-long string values (they're usually raw text blobs)."""
    if isinstance(obj, str):
        if len(obj) > max_str:
            return obj[:max_str] + f"...[clipped {len(obj) - max_str} chars]"
        return obj
    if isinstance(obj, dict):
        return {k: _clip_strings(v, max_str) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_clip_strings(v, max_str) for v in obj]
    return obj


def _cap_rows(obj, max_rows):
    """Cap very long arrays of records, keeping the first N and noting the rest."""
    if isinstance(obj, list) and len(obj) > max_rows:
        kept = [_cap_rows(x, max_rows) for x in obj[:max_rows]]
        kept.append({"_note": f"{len(obj) - max_rows} more rows omitted to fit size budget"})
        return kept
    if isinstance(obj, list):
        return [_cap_rows(x, max_rows) for x in obj]
    if isinstance(obj, dict):
        return {k: _cap_rows(v, max_rows) for k, v in obj.items()}
    return obj


def _size(obj) -> int:
    try:
        return len(obj if isinstance(obj, str) else json.dumps(obj, default=str))
    except Exception:  # noqa: BLE001
        return len(str(obj))


def _compact_doc(content, per_doc_budget):
    """Compact one document: clip long strings, cap huge row arrays, and if it
    is still over budget, hard-truncate its serialized form as a last resort."""
    content = _clip_strings(content, CONDENSE_MAX_STR)
    content = _cap_rows(content, CONDENSE_MAX_ROWS)
    if _size(content) <= per_doc_budget:
        return content
    # last resort: serialise and truncate, keeping valid-ish text
    s = content if isinstance(content, str) else json.dumps(content, default=str)
    return {"_truncated_document": s[:per_doc_budget] + f"...[clipped, doc exceeded {per_doc_budget} chars]"}


def _condense_documents(documents, tech_spec_files, vbop_files, total_budget):
    """Return (condensed_documents, report).

    Priority: tech spec and VBOP are kept as fully as possible; other files are
    compacted and, if the combined size still exceeds total_budget, dropped to a
    short placeholder (never silently lost - a note is left).
    """
    priority = set(tech_spec_files or []) | set(vbop_files or [])
    report = {"size_before": _size(documents), "compacted_files": [], "dropped_files": [],
              "truncated": False}

    # Priority docs get a bigger per-doc budget; others the standard one.
    prio_budget = max(CONDENSE_PER_DOC_BUDGET * 3, total_budget // 2)

    condensed = {}
    # 1) place priority docs first, compacted to their larger budget
    for name in list(documents.keys()):
        if name in priority:
            condensed[name] = _compact_doc(documents[name], prio_budget)

    # 2) then the rest, compacted to the standard per-doc budget
    for name, content in documents.items():
        if name in priority:
            continue
        condensed[name] = _compact_doc(content, CONDENSE_PER_DOC_BUDGET)

    # 3) enforce the TOTAL budget: if still over, drop non-priority docs
    #    (largest first) to short placeholders until we fit.
    def total():
        return _size(condensed)

    if total() > total_budget:
        report["truncated"] = True
        non_prio = sorted(
            [n for n in condensed if n not in priority],
            key=lambda n: _size(condensed[n]), reverse=True,
        )
        for name in non_prio:
            if total() <= total_budget:
                break
            condensed[name] = {"_omitted": f"'{name}' omitted to fit the size budget; "
                                          "compact fields were kept where possible."}
            report["dropped_files"].append(name)

    # record which files were compacted vs left whole
    for name in documents:
        if _size(condensed.get(name)) < _size(documents[name]):
            report["compacted_files"].append(name)
    report["size_after"] = total()
    if report["size_after"] < report["size_before"]:
        report["truncated"] = True
    return condensed, report


_storage_client = None


# ─────────────────────────────────────────────────────────────────────
# Deterministic size control (pure Python - never calls the model, so it
# can never hit the proxy's request-size cap). Guarantees each document,
# and the whole set, stays under a character budget before it ever reaches
# an agent.
# ─────────────────────────────────────────────────────────────────────
def _doc_len(obj) -> int:
    try:
        return len(obj if isinstance(obj, str) else json.dumps(obj, default=str))
    except Exception:  # noqa: BLE001
        return len(str(obj))


# Keywords the validation/extraction checks actually compare on. When a
# document is too big, we keep the rows/lines/keys that mention any of these
# and drop the rest, so nothing check-relevant is lost while the bulk goes.
_RELEVANT_KEYS = (
    "customer", "company", "client", "bill", "ship", "account",
    "opportunity", "opp", "reference", "ref", "po", "purchase order",
    "quote", "vendor", "supplier", "price", "cost", "sell", "margin",
    "product", "code", "sku", "part", "item", "quantity", "qty",
    "site", "address", "eircode", "premise", "location", "contact",
    "email", "mobile", "phone", "name",
    "contract", "term", "speed", "bandwidth", "service", "circuit",
    "date", "expiry", "valid", "lead", "leadtime",
    "qos", "af", "ef", "recurring", "billing", "frequency",
    "eir", "enet", "siro", "ripplecom", "nni", "eil", "sab", "qdc",
)


def _mentions_relevant(text: str) -> bool:
    low = text.lower()
    return any(k in low for k in _RELEVANT_KEYS)


def _shrink_to_budget(name, content, budget):
    """Reduce a single document below `budget` characters, deterministically.

    Strategy, in order, keeping check-relevant content:
      - list of row-dicts (spreadsheet): keep rows that mention relevant keys,
        then cap the number of rows, noting how many were omitted.
      - dict: keep relevant keys; truncate very long string values.
      - text: keep relevant lines; head+tail truncate if still over.
    Returns (shrunk_content, note or None).
    """
    if _doc_len(content) <= budget:
        return content, None

    # 1) List of rows (most common bloat shape)
    if isinstance(content, list):
        rows = content
        # Keep rows that still carry real (non-empty) content after pruning,
        # relevant ones first; these are what the checks actually read.
        def _row_score(r):
            s = json.dumps(r, default=str)
            has_data = not _is_empty(r) and s not in ("{}", "[]", "null")
            return (0 if _mentions_relevant(s) else 1, 0 if has_data else 1)
        ordered = sorted(rows, key=_row_score)
        kept, used = [], 0
        for r in ordered:
            if _is_empty(r):
                continue
            rlen = _doc_len(r) + 2
            if used + rlen > budget - 200:  # leave room for the note
                break
            kept.append(r)
            used += rlen
        omitted = len(rows) - len(kept)
        note = (f"[shrunk: kept {len(kept)} of {len(rows)} rows "
                f"(data/relevant-first), {omitted} omitted to fit size budget]")
        result = kept + [{"_note": note}]
        # hard guarantee under budget
        while _doc_len(result) > budget and len(result) > 1:
            result.pop(0)
        return result, note

    # 2) Dict: keep relevant keys, truncate long values
    if isinstance(content, dict):
        out, used, dropped = {}, 0, 0
        # relevant keys first
        items = sorted(content.items(),
                       key=lambda kv: 0 if _mentions_relevant(str(kv[0])) else 1)
        for k, v in items:
            vs = v if isinstance(v, str) else json.dumps(v, default=str)
            if len(vs) > 2000:
                vs = vs[:2000] + "...[truncated]"
                v = vs
            klen = len(str(k)) + len(vs) + 4
            if used + klen > budget:
                dropped += 1
                continue
            out[k] = v
            used += klen
        if dropped:
            out["_note"] = f"[shrunk: {dropped} less-relevant keys dropped to fit size budget]"
        return out, out.get("_note")

    # 3) Plain text: keep relevant lines, else head+tail
    text = content if isinstance(content, str) else str(content)
    lines = text.splitlines()
    relevant_lines = [ln for ln in lines if _mentions_relevant(ln)]
    joined = "\n".join(relevant_lines)
    if relevant_lines and len(joined) <= budget:
        return (joined + f"\n[shrunk: kept {len(relevant_lines)} of {len(lines)} "
                f"relevant lines to fit size budget]"), "shrunk-text"
    marker = "\n...[middle truncated to fit size budget]...\n"
    half = max(0, (budget - len(marker)) // 2)
    return (text[:half] + marker + text[-half:]), "truncated-text"





def _client() -> storage.Client:
    global _storage_client
    if _storage_client is None:
        _storage_client = storage.Client(project=PROJECT_ID)
    return _storage_client


# Filenames that identify the tech spec document. Folder names vary but the
# filename always contains something like "tech spec" / "tec spec" /
# "tech_spec" / "techspec" (any case, any separator).
_TECH_SPEC_RE = re.compile(r"te[ck]h?(?:nical)?[\s_\-\.]*spec", re.IGNORECASE)


def _is_tech_spec(blob_name: str) -> bool:
    filename = blob_name.rsplit("/", 1)[-1]
    return bool(_TECH_SPEC_RE.search(filename))


def _strip_ext(filename: str) -> str:
    # drop compound extensions like ".pdf.json" -> "file"
    name = filename.rsplit("/", 1)[-1]
    for _ in range(2):
        base, dot, ext = name.rpartition(".")
        if dot and len(ext) <= 5:
            name = base
        else:
            break
    return name


def _is_vbop(blob_name: str, opportunity_id: str) -> bool:
    """The VBOP file is named ONLY by the opportunity id, e.g. 'opp-1234567'.
    Match when the filename stem equals the opp id (case-insensitive), optionally
    with an 'opp-'/'opp_' prefix."""
    stem = _strip_ext(blob_name).strip().lower()
    oid = opportunity_id.strip().lower()
    candidates = {oid, f"opp-{oid}", f"opp_{oid}", f"opp{oid}"}
    # also handle stems that are exactly the id with an opp prefix already
    return stem in candidates or stem.lstrip("opp-_") == oid.lstrip("opp-_")


def get_opportunity_data(opportunity_id: str, tool_context: ToolContext) -> dict:
    """Retrieve all parsed documents for a given opportunity id from GCS.

    The bucket is organised as one folder per opportunity:
        gs://<bucket>/<base prefix>/<folder containing the opportunity id>/<parsed files>

    The folder name does not need to equal the opportunity id exactly -
    it only needs to CONTAIN it (e.g. folder "4234-opp-5555363773" matches
    opportunity id "5555363773").

    Args:
        opportunity_id: The opportunity id to look for inside folder names.

    Returns:
        dict with:
            status: "success" | "not_found" | "error"
            opportunity_id: echo of the input
            files: list of {name, size_bytes, loaded}
            documents: {filename: parsed content} for every loaded file
    """
    opportunity_id = opportunity_id.strip().strip("/")
    base_prefix = f"{GCS_BASE_PREFIX}/" if GCS_BASE_PREFIX else ""

    ## Folder names are not always exactly the opp id - they may just
    ## CONTAIN it (e.g. "4234-opp-5555363773" for opp id "5555363773").
    ## So first list the folders under the base path and match by substring.
    try:
        bucket = _client().bucket(GCS_BUCKET_NAME)

        listing = bucket.list_blobs(prefix=base_prefix, delimiter="/")
        # .prefixes is only populated after the iterator is consumed
        _ = list(listing)
        folders = sorted(listing.prefixes)  # e.g. ["base/4234-opp-5555363773/", ...]
    except Exception as exc:  # noqa: BLE001
        return {
            "status": "error",
            "opportunity_id": opportunity_id,
            "message": f"Failed to list gs://{GCS_BUCKET_NAME}/{base_prefix}: {exc}",
        }

    def _folder_name(full_prefix: str) -> str:
        return full_prefix[len(base_prefix):].strip("/")

    matches = [
        p for p in folders
        if opportunity_id.lower() in _folder_name(p).lower()
    ]

    # The pipeline consolidates each opportunity into a folder named EXACTLY
    # after its id (e.g. "OPP-0007063044/"). Older runs mirrored the source
    # layout ("6523_OPP-0007063044_02012025_1046/"), and both can coexist in
    # the bucket — a plain substring match then reports "ambiguous" and every
    # check fails for the wrong reason. An exact name match is unambiguous by
    # construction, so prefer it and ignore the legacy variants.
    exact = [
        p for p in matches
        if _folder_name(p).lower() == opportunity_id.lower()
    ]
    if exact:
        matches = exact[:1]

    if not matches:
        return {
            "status": "not_found",
            "opportunity_id": opportunity_id,
            "message": (
                f"No folder under gs://{GCS_BUCKET_NAME}/{base_prefix} contains "
                f"'{opportunity_id}' in its name. Check the opportunity id or "
                "confirm the parsed files were uploaded."
            ),
            "available_folders": [_folder_name(p) for p in folders][:50],
        }

    if len(matches) > 1:
        return {
            "status": "ambiguous",
            "opportunity_id": opportunity_id,
            "message": (
                f"Multiple folders contain '{opportunity_id}'. "
                "Report the candidates and ask which one to use, or retry "
                "with a more specific opportunity id."
            ),
            "matching_folders": [_folder_name(p) for p in matches],
        }

    prefix = matches[0]
    matched_folder = _folder_name(prefix)

    try:
        blobs = [b for b in bucket.list_blobs(prefix=prefix) if not b.name.endswith("/")]
    except Exception as exc:  # noqa: BLE001
        return {
            "status": "error",
            "opportunity_id": opportunity_id,
            "message": f"Failed to access gs://{GCS_BUCKET_NAME}/{prefix}: {exc}",
        }

    if not blobs:
        return {
            "status": "not_found",
            "opportunity_id": opportunity_id,
            "matched_folder": matched_folder,
            "message": (
                f"Folder gs://{GCS_BUCKET_NAME}/{prefix} matched the opportunity id "
                "but contains no files."
            ),
        }

    documents: dict = {}
    manifest: list = []

    # Pipeline-written metadata that must never be treated as a document.
    _PIPELINE_META = {STATUS_FILENAME, "validation.json", "_versions.json"}

    for blob in blobs:
        base = blob.name.rsplit("/", 1)[-1]
        # Never re-ingest our own saved status / validation / version files.
        if base in _PIPELINE_META:
            continue
        # list_blobs is RECURSIVE: without this, archive/ (every superseded
        # document version) would be ingested alongside the current ones,
        # e.g. an expired vendor quote next to the valid one, which would
        # fail expiry/consistency checks for the wrong reason.
        if "/archive/" in blob.name:
            continue

        entry = {
            "name": blob.name,
            "size_bytes": blob.size,
            "loaded": False,
            "is_tech_spec": _is_tech_spec(blob.name),
        }

        try:
            raw = blob.download_as_bytes()
            text = raw.decode("utf-8", errors="replace")

            # Try to parse as JSON regardless of extension - the huge
            # spreadsheet-style files may not always be named .json.
            parsed_json = None
            try:
                parsed_json = json.loads(text)
            except (json.JSONDecodeError, ValueError):
                parsed_json = None

            if parsed_json is not None:
                before = len(text)
                parsed_json, removed = _prune_empty(parsed_json)
                if removed:
                    entry["pruned_empty_fields"] = removed
                    after = len(json.dumps(parsed_json))
                    entry["size_before"] = before
                    entry["size_after"] = after
                    print(f"[prune] {blob.name}: removed {removed} empty auto-keys, "
                          f"{before} -> {after} chars "
                          f"({100 * (before - after) // max(before, 1)}% smaller)")
                content = parsed_json
            else:
                content = text

            # Deterministic size cap per document (bigger share for tech spec).
            budget = MAX_TECHSPEC_CHARS if entry["is_tech_spec"] else MAX_DOC_CHARS
            pre = _doc_len(content)
            if pre > budget:
                content, note = _shrink_to_budget(blob.name, content, budget)
                entry["shrunk"] = True
                entry["size_before_shrink"] = pre
                entry["size_after_shrink"] = _doc_len(content)
                print(f"[shrink] {blob.name}: {pre} -> {entry['size_after_shrink']} "
                      f"chars (budget {budget}) {note or ''}")

            documents[blob.name] = content
            entry["loaded"] = True
        except Exception as exc:  # noqa: BLE001
            entry["skipped_reason"] = f"download/decode failed: {exc}"

        manifest.append(entry)

    # Persist for downstream agents (BSP extractor) via session state.
    tech_spec_files = [e["name"] for e in manifest if e["is_tech_spec"] and e["loaded"]]

    # The VBOP file is named only by the opportunity id.
    for e in manifest:
        e["is_vbop"] = _is_vbop(e["name"], opportunity_id)
    vbop_files = [e["name"] for e in manifest if e["is_vbop"] and e["loaded"]]

    # Existing validation status saved by a previous run (if any).
    existing_status = None
    status_blob_name = f"{prefix}{STATUS_FILENAME}"
    try:
        sb = bucket.blob(status_blob_name)
        if sb.exists():
            existing_status = json.loads(sb.download_as_text())
    except Exception:  # noqa: BLE001 - existing status is best effort
        existing_status = None

    # Total-budget backstop: if the combined documents still exceed the total
    # budget, shrink the largest non-tech-spec docs further until they fit.
    def _total_len(docs):
        return sum(_doc_len(v) for v in docs.values())

    total = _total_len(documents)
    if total > MAX_TOTAL_DOC_CHARS:
        techspec_names = {e["name"] for e in manifest if e["is_tech_spec"]}
        # shrink biggest non-tech-spec docs first
        shrinkable = sorted(
            (n for n in documents if n not in techspec_names),
            key=lambda n: _doc_len(documents[n]), reverse=True,
        )
        for n in shrinkable:
            if _total_len(documents) <= MAX_TOTAL_DOC_CHARS:
                break
            cur = _doc_len(documents[n])
            headroom = max(2000, cur - (total - MAX_TOTAL_DOC_CHARS))
            documents[n], _ = _shrink_to_budget(n, documents[n], min(cur, headroom))
        print(f"[total-budget] combined docs {total} -> {_total_len(documents)} "
              f"chars (budget {MAX_TOTAL_DOC_CHARS})")

    tool_context.state["opportunity_id"] = opportunity_id
    tool_context.state["template_date"] = date.today().isoformat()
    tool_context.state["opportunity_folder"] = matched_folder
    tool_context.state["opportunity_prefix"] = prefix  # full GCS prefix for save/load
    tool_context.state["opportunity_file_manifest"] = manifest
    tool_context.state["tech_spec_files"] = tech_spec_files
    tool_context.state["vbop_files"] = vbop_files
    tool_context.state["existing_validation_status"] = existing_status

    # Guarantee the payload handed to the agents stays under the model's
    # input cap, no matter how large a single file is. Tech spec + VBOP are
    # preserved as fully as possible; other documents are compacted (long
    # strings clipped, huge row-arrays sampled). Deterministic, no model call.
    condensed, condense_report = _condense_documents(
        documents,
        tech_spec_files=tech_spec_files,
        vbop_files=vbop_files,
        total_budget=_condense_budget(),
    )
    tool_context.state["opportunity_data"] = condensed
    tool_context.state["opportunity_data_full"] = documents  # raw, if ever needed
    tool_context.state["condense_report"] = condense_report
    if condense_report.get("truncated"):
        print(f"[condense] payload {condense_report['size_before']} -> "
              f"{condense_report['size_after']} chars (budget {_condense_budget()}); "
              f"compacted: {condense_report['compacted_files']}")

    return {
        "status": "success",
        "opportunity_id": opportunity_id,
        "matched_folder": matched_folder,
        "tech_spec_files": tech_spec_files or "WARNING: no tech spec document found in this folder",
        "vbop_files": vbop_files or "WARNING: no VBOP file (named by opportunity id) found in this folder",
        "existing_validation_status": existing_status or "none - first run for this opportunity",
        "condense_report": condense_report,
        "files": manifest,
        "documents": condensed,
    }


# ─────────────────────────────────────────────────────────────────────
# BigQuery lookups for BSP internal validation
# ─────────────────────────────────────────────────────────────────────


def _bq_table(table_name: str) -> str:
    """Build a fully-qualified `project.dataset.table` reference.

    BQ_DATASET may already be project-qualified (e.g.
    "vf-ie-datahub.vfie_dh_lake_customer_complex_fixed_s"). In that case we must
    NOT prepend BQ_PROJECT again (that yields an invalid 4-part name). If the
    dataset has no dot, we qualify it with BQ_PROJECT.
    """
    ds = BQ_DATASET.strip().strip("`")
    if "." in ds:
        fqn = f"{ds}.{table_name}"          # dataset already includes its project
    else:
        fqn = f"{BQ_PROJECT}.{ds}.{table_name}"
    return f"`{fqn}`"

_bq_client = None


def _bq():
    global _bq_client
    if _bq_client is None:
        from google.cloud import bigquery
        _bq_client = bigquery.Client(project=BQ_PROJECT)
    return _bq_client


def _rows_to_dicts(job, limit=25):
    out = []
    for i, row in enumerate(job):
        if i >= limit:
            break
        out.append({k: (str(v) if v is not None else None) for k, v in dict(row).items()})
    return out


def lookup_bsp_company(name: str, tool_context: ToolContext) -> dict:
    """Look up a customer / company in BSP (BigQuery TEMP_company).

    Tries an exact UPPER(TRIM(name)) match first, then a LIKE contains-match,
    so the agent can judge the closest match. Use for:
      - customer name validation (base check 1)
      - billing entity / bill_to_name validation (base check 3)

    Args:
        name: The customer or billing entity name from the tech spec / order form.

    Returns:
        dict with exact_matches, like_matches (closest candidates), and counts.
    """
    from google.cloud import bigquery

    table = _bq_table("TEMP_company")
    safe = (name or "").strip()
    params = [bigquery.ScalarQueryParameter("val", "STRING", safe.upper())]
    cfg = bigquery.QueryJobConfig(query_parameters=params)

    try:
        exact_sql = f"SELECT * FROM {table} WHERE UPPER(TRIM(`name`)) = @val"
        exact = _rows_to_dicts(_bq().query(exact_sql, job_config=cfg))

        like_cfg = bigquery.QueryJobConfig(query_parameters=[
            bigquery.ScalarQueryParameter("val", "STRING", f"%{safe.upper()}%")
        ])
        like_sql = f"SELECT * FROM {table} WHERE UPPER(TRIM(`name`)) LIKE @val LIMIT 25"
        like = _rows_to_dicts(_bq().query(like_sql, job_config=like_cfg))
    except Exception as exc:  # noqa: BLE001
        import traceback
        detail = f"{type(exc).__name__}: {exc}"
        print("=" * 70)
        print(f"[BQ ERROR] lookup_bsp_company FAILED")
        print(f"[BQ ERROR] table  = {table}")
        print(f"[BQ ERROR] project= {BQ_PROJECT}")
        print(f"[BQ ERROR] {detail}")
        traceback.print_exc()
        print("=" * 70)
        return {"status": "error", "query": name, "table": table,
                "error_type": type(exc).__name__, "message": detail}

    return {
        "status": "success",
        "query": name,
        "exact_match_count": len(exact),
        "exact_matches": exact,
        "like_match_count": len(like),
        "like_matches": like,
    }


def lookup_bsp_location(location: str, eircode: str, tool_context: ToolContext) -> dict:
    """Look up a delivery / service address in BSP (BigQuery TEMP_location).

    Matches against the concatenated name + address_1..address_3 via a
    contains (LIKE) search. If an Eircode is provided it is tried as an
    additional, more precise search. Use for:
      - delivery address validation (base check 2)
      - service address validation (circuit check 6)

    Args:
        location: The address string from the tech spec / circuit order form.
        eircode: Optional Eircode; pass "" if none.

    Returns:
        dict with address_matches, eircode_matches (if any), and counts.
    """
    from google.cloud import bigquery

    table = _bq_table("TEMP_location")
    concat = ("UPPER(CONCAT("
              "IFNULL(`name`,''),' ',"
              "IFNULL(`address_1`,''),' ',"
              "IFNULL(`address_2`,''),' ',"
              "IFNULL(`address_3`,'')"
              "))")
    result = {"status": "success", "query": location, "eircode": eircode or None}

    try:
        loc_cfg = bigquery.QueryJobConfig(query_parameters=[
            bigquery.ScalarQueryParameter("val", "STRING", f"%{(location or '').strip().upper()}%")
        ])
        loc_sql = f"SELECT * FROM {table} WHERE {concat} LIKE @val LIMIT 25"
        addr = _rows_to_dicts(_bq().query(loc_sql, job_config=loc_cfg))
        result["address_match_count"] = len(addr)
        result["address_matches"] = addr

        if eircode and eircode.strip():
            ec_cfg = bigquery.QueryJobConfig(query_parameters=[
                bigquery.ScalarQueryParameter("val", "STRING", f"%{eircode.strip().upper()}%")
            ])
            ec_sql = f"SELECT * FROM {table} WHERE {concat} LIKE @val LIMIT 25"
            ec = _rows_to_dicts(_bq().query(ec_sql, job_config=ec_cfg))
            result["eircode_match_count"] = len(ec)
            result["eircode_matches"] = ec
    except Exception as exc:  # noqa: BLE001
        import traceback
        detail = f"{type(exc).__name__}: {exc}"
        print("=" * 70)
        print(f"[BQ ERROR] lookup_bsp_location FAILED")
        print(f"[BQ ERROR] table  = {table}")
        print(f"[BQ ERROR] project= {BQ_PROJECT}")
        print(f"[BQ ERROR] {detail}")
        traceback.print_exc()
        print("=" * 70)
        return {"status": "error", "query": location, "table": table,
                "error_type": type(exc).__name__, "message": detail}

    return result


# ─────────────────────────────────────────────────────────────────────
# Persist / retrieve validation status in the opportunity's GCS folder
# so re-runs show the latest status and other users can track it.
# ─────────────────────────────────────────────────────────────────────
def save_validation_status(status_json: str, tool_context: ToolContext) -> dict:
    """Save the full validation status back to the opportunity's GCS folder
    as validation_status.json, so it is retrieved on future runs and other
    users can track progress.

    Args:
        status_json: The complete validation status as a JSON string. Should
            contain the checks and their results/notes/actions and any human
            feedback records (option, comment, saved date).

    Returns:
        dict with the GCS path written, or an error.
    """
    prefix = tool_context.state.get("opportunity_prefix")
    opp_id = tool_context.state.get("opportunity_id", "")
    if not prefix:
        return {"status": "error",
                "message": "No opportunity_prefix in state - call get_opportunity_data first."}

    try:
        payload = json.loads(status_json) if isinstance(status_json, str) else status_json
    except json.JSONDecodeError as exc:
        return {"status": "error", "message": f"status_json is not valid JSON: {exc}"}

    # stamp the save time
    payload.setdefault("opportunity_id", opp_id)
    payload["last_saved_utc"] = datetime.utcnow().isoformat() + "Z"

    blob_name = f"{prefix}{STATUS_FILENAME}"
    try:
        bucket = _client().bucket(GCS_BUCKET_NAME)
        bucket.blob(blob_name).upload_from_string(
            json.dumps(payload, indent=2), content_type="application/json"
        )
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "message": f"Failed to write gs://{GCS_BUCKET_NAME}/{blob_name}: {exc}"}

    tool_context.state["existing_validation_status"] = payload
    return {"status": "success",
            "path": f"gs://{GCS_BUCKET_NAME}/{blob_name}",
            "last_saved_utc": payload["last_saved_utc"]}


def get_validation_status(opportunity_id: str, tool_context: ToolContext) -> dict:
    """Retrieve the previously saved validation_status.json for an opportunity
    (without re-downloading all documents). Resolves the folder the same way
    get_opportunity_data does.

    Args:
        opportunity_id: The opportunity id.

    Returns:
        dict with the saved status, or status "not_found".
    """
    opportunity_id = opportunity_id.strip().strip("/")
    base_prefix = f"{GCS_BASE_PREFIX}/" if GCS_BASE_PREFIX else ""
    try:
        bucket = _client().bucket(GCS_BUCKET_NAME)
        listing = bucket.list_blobs(prefix=base_prefix, delimiter="/")
        _ = list(listing)
        folders = sorted(listing.prefixes)
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "message": str(exc)}

    def _fn(p):
        return p[len(base_prefix):].strip("/")

    matches = [p for p in folders if opportunity_id.lower() in _fn(p).lower()]
    if not matches:
        return {"status": "not_found", "opportunity_id": opportunity_id,
                "message": "No folder contains this opportunity id."}
    prefix = matches[0]
    blob_name = f"{prefix}{STATUS_FILENAME}"
    try:
        blob = bucket.blob(blob_name)
        if not blob.exists():
            return {"status": "not_found", "opportunity_id": opportunity_id,
                    "message": "No saved validation status yet."}
        return {"status": "success", "opportunity_id": opportunity_id,
                "validation_status": json.loads(blob.download_as_text())}
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "message": str(exc)}

# ─────────────────────────────────────────────────────────────────────
# VALIDATION_PROMPT (inlined from Agent/prompts.py)
# ─────────────────────────────────────────────────────────────────────
VALIDATION_PROMPT = """
You are a Vodafone Ireland quote-to-order validation specialist.

WORKFLOW
0. The request states today's PROCESSING DATE. Use it only where a rule
   explicitly calls for it (e.g. the VAL-008 staleness note). Never assume
   today's date from memory — dates in documents are historical.
1. The user will provide an OPPORTUNITY ID (it may be embedded in a sentence).
   Extract it and call the tool `get_opportunity_data` with that id.
2. If the tool returns "not_found" or "error", report the problem clearly,
   answer "N" for every check with the problem in the notes, and still
   produce the full JSON. Never stop the pipeline.
   If the tool returns "ambiguous" (multiple folders contain the opportunity
   id), list the candidate folders in the notes/blocking_issues, answer "N"
   for every check, and state that a more specific opportunity id is needed.
   On success, put the matched folder name in the "matched_folder" field so
   a human can confirm the right folder was used.
3. Treat the returned documents (PO, signed contract, customer quote, vendor
   quotes, circuit order form, HLD / solution design, site details, etc.)
   as your only knowledge base. Do not invent information.
   The VBOP file is named ONLY by the opportunity id (e.g. "opp-1234567");
   the tool reports it in "vbop_files". "Validate against VBOP" means check
   against this file.
4. Run the REQUIRED INFORMATION review and every DOCUMENT VALIDATION CHECK.
5. Run the BSP INTERNAL VALIDATION (base checks B1-B12, and circuit checks
   X1-X9 only when the order category is Circuit). For these you MUST use the
   BigQuery tools:
     - lookup_bsp_company(name)          -> customer & billing entity checks
     - lookup_bsp_location(location, eircode) -> delivery & service address
   Call them with the values you extracted from the tech spec / order form.
   Use the closest match (exact match preferred; otherwise judge the best
   LIKE candidate). Only decide Y/N after seeing the tool results.

ORDER TYPE (from the VBOP file):
   Determine the order category from the VBOP file (and tech spec). The two
   major categories are "Kit" and "Circuit" (others possible).
   - Put it in "order_category" in the output.
   - If the category is Circuit: include the "circuit_checks" object with all
     X1-X9 evaluated.
   - If the category is NOT Circuit (e.g. Kit): OMIT the "circuit_checks"
     object entirely from the JSON (do not include X-checks at all).
   Always include "bsp_base_checks" for every order type.

EXISTING STATUS (re-runs):
   The tool result / state may contain "existing_validation_status" from a
   previous run, including human feedback (option, comment, saved date). When
   present, carry that feedback forward: keep each check's prior "feedback"
   record in your output so status is preserved and other users can track it.
   Do not erase feedback a human already recorded.

REQUIRED INFORMATION - confirm each item exists in the documents:
R1.  PO / signed contract
R2.  Quote to the customer
R3.  Quote from the vendor, with clear instruction on what to order and from whom
R4.  Site ID
R5.  Site contact info
R6.  Summary of what has been sold and/or designed (HLD if solution design is involved)
R7.  The summary must cover:
     - what services we are supplying
     - what we are deploying
     - any specific engineering asks (e.g. integration)
     - any specific engineering requirements
     - what lead time (if any) has been indicated to the customer

VALIDATION CHECKS - evaluate each one:
C1.  If a lead time was given to the customer, is it aligned to product KPIs?
C2.  Is the circuit order form attached?
C3.  Is the PO/quote attached, and is it signed?
C4.  Is it clear which vendor the order is for?
C5.  Third-party usage, per vendor:
     - EIR fibre: is the QDC (Quotation of Data Circuit) from eir attached,
       and are the EIL and SAB attached?
     - enet: is the quote attached?
     - SIRO: is the site premises included, to obtain order details on the SIRO port?
     - Ripplecom / host: is the quote attached?
     - For ALL vendors: is the vendor quote attached?
C6.  Are the correct infrastructure orders attached (sales enablement)?
     Are they correct regarding product and speed?
C7.  Is the site information correct: Site ID, Site Name, Site Address?
C8.  Are the site contact details provided: contact name, email, mobile number?
C9.  Does the summary / design / order match the attached design and order form?
C10. Is the correct customer account / company name used so the customer is
     billed correctly? (Some customers have multiple accounts - verify the
     right one has been chosen.)
C11. For DIA orders: have the customer's LAN IP details been provided?
C12. If the customer requested public IP address ranges, has this been approved?
C13. Is the customer requesting IP address ranges from the standard offering (/30)?
C14. Is the kit correct - is the router compatible with the product being
     ordered, and is the fulfilment rate / ship-back correct (sales enablement)?
C15. Are all power supplies, antennas, extension cables and licences
     requested on the order?
C16. Is the 3rd-party installation included in the quote?
C17. Is the contract term provided, and does it match the order?
C18. Has the B-End info (if required) been filled out and is it correct?
     (EIL, SAB, exchange for eir, enet NNI)
C19. If QoS (Quality of Service) is required, is it filled in and correct -
     AF & EF percentages on the quote form?
C20. If existing services are to be CEASED after the new service is completed,
     are the cease details included in the request (including delivery notes
     if the customer requires migration and cease from another VF service
     once the new service is delivered)?
C21. If the order is an upgrade / downgrade, is this CLEARLY stated?
C22. If any comment refers to a certain email or file, is that email/file
     actually attached?
C23. Is the vendor quote out of date? (Check the quote's validity/expiry
     date against today's date {template_date?}. Y here means the quote is
     STILL VALID - answer N if it has expired or no validity date is found.)
C24. Is the VF Quote to Customer attached?
C25. Has a lead time (if any) been indicated to the customer, and is it
     stated in the documents?
C26. Are the Vendor Quotations attached?
C27. Is the appropriate tech spec included WITH commercial approval,
     including margin? Evidence can be: output from the self-approved
     pricing tool, EDRA, or an email approval from the commercial manager.
     If there are multiple quotes, relevant notes/explanations must be
     included.

BSP INTERNAL VALIDATION - BASE CHECKS (all order types):
B1.  Customer name: the customer name in the tech spec / order form must
     match (or closely match) a company in BSP. Call lookup_bsp_company.
     If no acceptable match -> N, action "raise_mdg".
B2.  Delivery address (from tech spec) must exist in BSP. Call
     lookup_bsp_location (pass the Eircode if present). If absent -> N,
     action "raise_bsp".
B3.  Billing entity name (tech spec / order form) must match bill_to_name in
     BSP. Call lookup_bsp_company. If no match -> N, action "raise_mdg".
B4.  Opportunity reference number in the tech spec must match the one in the
     VBOP file (correct obvious typos and note the correction). Mismatch that
     is not a clear typo -> N.
B5.  PO number: the PO number in the VBOP must be consistent with the
     customer PO. If no PO exists, at least one email confirmation from the
     customer is required, and the PO must be the same across all documents.
     Missing/inconsistent -> N, action "raise_sales".
B6.  Cost vs sell price: the vendor PO price must be LESS THAN the selling
     price in the Vodafone quote and the customer PO. Validate across vendor
     PO, Vodafone quote, and customer PO. Any violation -> N.
B7.  Product code (docs): every product code in the tech spec must appear in
     the vendor quote. If a code is missing, its product NAME must appear
     somewhere (vendor/customer PO / tech spec / vendor quote). Otherwise -> N.
B8.  Product code (BSP/MDM): every code in the tech spec should exist in BSP
     (via MDM). If a code is not found -> N, action "raise_mdm".
B9.  Quantity: quantity for each product in the tech spec must align across
     all files. The vendor quote MAY be higher, but never lower. Mismatch -> N.
B10. Vendor quote expiry: compare today's date ({template_date?}) with the
     vendor quotation date / expiry date / email date. Valid for 30 days only.
     If expired -> N (mark "expired").
B11. Contact: contact name & details in the tech spec must be complete
     (name, email, mobile). Incomplete -> N.
B13. Billing address: the billing address must (1) be present in the
     documents (tech spec / order form / customer PO) AND (2) exist in BSP.
     Call lookup_bsp_location with the billing address (pass its Eircode if
     present). If it is missing from the documents OR not found in BSP -> N,
     action "raise_bsp".
B12. Order readiness: aggregate of all previous checks. Y only if all
     mandatory base checks pass.

BSP INTERNAL VALIDATION - CIRCUIT CHECKS (order category = Circuit only;
if the order is not Circuit, answer every X-check "Y" with note
"Not applicable - not a circuit order"):
X1.  Contract term present in circuit order form or tech spec.
X2.  Premise ID present in circuit order form or tech spec - REQUIRED for
     SIRO vendors (for non-SIRO, Y with note "Not applicable - not SIRO").
X3.  Service type present in circuit order form / tech spec and matches the
     supporting documents.
X4.  Speed present in circuit order form / tech spec and matches the customer
     order form.
X5.  Product: product name and type exist.
X6.  Service address: the installation address from the circuit order form /
     tech spec must be present and match supporting docs AND BSP. Call
     lookup_bsp_location. If absent in BSP -> N, action "raise_bsp".
X7.  PO: PO number in the circuit order form must match the VBOP PO number.
     Missing / mismatch -> N.
X8.  Billing frequency present in circuit order form / tech spec and aligned
     with the rest of the order.
X9.  Recurring order: the PO type in the circuit order form / tech spec must
     be set to Recurring. Otherwise -> N.


═══════════════════════════════════════════════════════════════════════
VAL-Q2O VALIDATION CATALOGUE (authoritative — from Confluence CFAS)
═══════════════════════════════════════════════════════════════════════
Evaluate EVERY validation below and return them in the "val_checks" array.
Verdicts are "Y" (pass), "N" (fail) or "NA" (not applicable to this order
type — use this, never "N", when a rule does not apply).

BASE VALIDATIONS — evaluate for EVERY order, whatever the category.

VAL-001  Customer Name Validation
  The customer name in the Tech Spec or Order Form must EXACTLY match the
  Customer Name in BSP. Use lookup_bsp_company.
  N if: not present in BSP, or present but not an exact match.
  Action on N: raise_mdg (create via MDG, or reactivate if inactive).

VAL-002  Delivery Address Validation
  A delivery address must be provided in the Tech Spec.
  N if: missing from the Tech Spec.
  Action on N: raise_sales. If absent from BSP, note that the address must
  be created in BSP.

VAL-003  Billing Entity Validation
  The Billing Entity in the Tech Spec or Order Form must match the BSP
  Invoicing Customer Name. Use lookup_bsp_company.
  N if: it does not match.  Action on N: raise_mdg.

VAL-004  Opportunity Reference Validation
  The Opportunity Reference in the Tech Spec must exist in VBOP and match
  exactly.  N if: absent from VBOP, or mismatched.
  Action on N: raise_sales (check the Opportunity ID and update VBOP).

VAL-005  Customer Purchase Order (PO) Validation
  A Customer PO must exist in the VBOP attachments. A PO number OR an
  approval/confirmation email from the customer satisfies this.
  Y if: a PO document, PO number, or written customer confirmation exists —
  including a PO shown in an email screenshot embedded in a document
  (check "embedded_images" extractions as well as document text).
  N if: no PO number AND no customer confirmation of any kind.
  Where a PO reference appears in several documents it must be consistent.
  Action on N: raise_sales.

VAL-006  Cost vs Sell Price Validation
  Vodafone must sell above vendor cost on EVERY line item.
  N if: vendor cost >= customer sell price on ANY line item (name it).
  Use pricing from the source document; unresolvable pricing errors are
  blocking.  Action on N: raise_sales.

VAL-007  Quantity Validation
  Product quantities must be consistent across Tech Spec, Vendor Quote,
  Vodafone Quote, Customer PO and related documents. The vendor quote
  quantity must be >= the quantity elsewhere, so the order is fulfillable.
  N if: any product's quantity disagrees between documents.
  Action on N: raise_sales (request an updated vendor quote).

VAL-008  Vendor Quote Expiry Validation
  Judge validity AS AT THE CUSTOMER QUOTE DATE, not as at today. The
  question this rule answers is "was the vendor quote valid at the moment
  Vodafone quoted the customer?" — an old opportunity must not fail simply
  because it is being processed late.

  REFERENCE DATE — use the first of these you can establish, and say in the
  reasoning which one you used:
    1. the date the Vodafone/customer quote was issued or sent;
    2. failing that, the Customer PO date;
    3. failing that, the order form / tech spec date;
    4. only if none exist, the PROCESSING DATE given in the request.

  Y if ANY of the following held AT THE REFERENCE DATE:
    (a) the vendor quote carries an expiry date and the reference date is on
        or before it; or
    (b) the vendor quote date is within 30 days before the reference date; or
    (c) a vendor email confirms the quote was valid for that period.
  N if: there is no vendor quote date and no expiry date, or the quote had
        already expired at the reference date.
  Action on N: raise_sales (request an updated quote).

  Worked example — vendor quote expires 20/01/2025 and the customer quote
  was sent 25/12/2024: the quote WAS valid when the customer was quoted, so
  the verdict is "Y", whatever today's date is.

  STALENESS NOTE (does not change the verdict):
  After deciding Y, also compare the vendor quote expiry against the
  PROCESSING DATE supplied in the request. If the quote was valid at the
  reference date but has since expired, keep the verdict "Y" and:
    - append to the reasoning, in this exact form:
      "NOTE: valid at customer quote date <ref date> but expired <expiry
      date>; quote is stale as at processing date <processing date>."
    - add a matching entry to overall.needs_human_review so the staleness is
      visible without failing the order.
  Sales may still need a refreshed quote before ordering; that is a human
  decision, not a validation failure.

VAL-009  Contact Validation (Base)
  Order contact details must be available and complete: Contact Name
  present, and Contact Details present and complete.
  N if: name missing, or details missing/incomplete.
  Action on N: raise_sales.

VAL-013  Contract Term Validation
  A Contract Term must be specified in the Technical Specification.
  Y if: the field is present and holds a usable value (e.g. "36 Months").
  N if: missing, empty, null, or with no usable value.
  Action on N: raise_sales.

VAL-023  Recurring Item Contract Term Validation
  If the order contains ANY recurring item, a customer Contract Term MUST
  be set. Treat an item as recurring when the Tech Spec line item is marked
  "Recurring" (e.g. the "Once off / Recurring" column), when the PO Type is
  "Recurring", or when a billing frequency implies an ongoing charge.
  NA if: the order contains no recurring items (all once-off).
  Y if: recurring items exist AND a Contract Term is present with a usable
        value (e.g. 12 / 24 / 36 months).
  N if: recurring items exist AND the Contract Term is missing, blank, null
        or unusable. List the recurring line items in the reasoning.
  Action on N: raise_sales.
  Note: this is the CONDITIONAL counterpart to VAL-013. A recurring charge
  without an agreed term cannot be billed correctly, so it is blocking.

CIRCUIT VALIDATIONS — evaluate ONLY when order_category is Circuit.
For any non-circuit order (e.g. Kit) return "NA" for VAL-014..VAL-022 with
reasoning "not a circuit order".

VAL-014  Premise ID Validation
  Applies ONLY where the vendor is SIRO.
  NA if: vendor is not SIRO.
  Y if: vendor is SIRO and Premise ID is present, populated and valid.
  N if: vendor is SIRO and Premise ID is missing, empty or invalid.
  Action on N: raise_sales.

VAL-015  Service Validation
  A Service Type must be specified in the Tech Spec and be consistent with
  the supporting documentation (e.g. IPVPN in both).
  N if: missing/blank, or it disagrees with the supporting documents.
  Action on N: raise_sales.

VAL-016  Speed Validation
  The Circuit Speed in the Tech Spec must be present and match the Customer
  Order Form and any supporting documents.
  N if: missing/empty, or inconsistent between documents (state both values).
  Action on N: raise_sales.

VAL-017  Product Validation
  Sufficient product information: Product Name OR Product Type must be
  present and populated (either alone is enough).
  N ONLY if: BOTH Product Name and Product Type are missing or empty.
  Action on N: raise_sales.

VAL-018  Service Address Validation
  The Service Installation Address must be present and populated, match the
  supporting documentation, and match the BSP record. Where several service
  addresses are given, ALL must satisfy these conditions.
  Use lookup_bsp_location.
  N if: missing/empty, or it disagrees with supporting docs or BSP, or any
  one of multiple addresses fails.  Action on N: raise_mdg.

VAL-019  Contact Validation (Circuit)
  Contact Name and Contact Details must be present in the Circuit Order
  Form or Technical Specification; details must include a valid telephone
  number and/or email address.
  N if: name missing/empty, or details missing/incomplete/empty.
  Action on N: raise_sales.

VAL-020  PO Validation (Circuit)
  A PO Number must be present in the Circuit Order Form and match the PO
  Number recorded in VBOP.
  N if: missing/empty in the Circuit Order Form, or it differs from VBOP
  (quote both values).  Action on N: raise_sales.

VAL-021  Billing Frequency Validation
  A Billing Frequency must be present and populated in the Tech Spec and
  align with the agreed commercial and order requirements (e.g. monthly,
  quarterly, annually).
  N if: missing/blank, or inconsistent with the order requirements.
  Action on N: raise_sales.

VAL-022  Recurring Order Validation
  The PO Type in the Circuit Order Form or Tech Spec must be present and
  set to "Recurring".
  N if: missing/empty, or set to any value other than "Recurring".
  Action on N: raise_sales.

EVIDENCE RULES for val_checks
- Quote the actual values you compared (e.g. "Tech Spec 100 Mbps vs Order
  Form 1 Gbps"), not just "mismatch".
- Never guess. If a document needed for a check is absent, answer "N" and
  say which document is missing — except where the rule defines "NA".
- Check "embedded_images" extractions as well as document text: POs and
  signed approvals are often screenshots pasted into a spreadsheet.


OUTPUT FORMAT
The UI already knows every check's description, so DO NOT repeat check
descriptions/labels. Return only: the check KEY, the verdict, a short
reasoning, and (for base/circuit checks) the action. To minimise tokens,
each check is a COMPACT ARRAY, not an object:

    ["<key>", "<Y|N>", "<short reasoning>", "<action>"]

- Element 0: the check key exactly (e.g. "C1", "R4", "B8", "X2"). Use the
  SHORT ids R1..R7, C1..C27, B1..B12, X1..X9 - not the long names.
- Element 1: exactly "Y" or "N" (never PASS/FAIL/yes/no).
- Element 2: a SHORT reasoning (one sentence, keep it brief).
- Element 3: action - ONLY for B* and X* checks; OMIT it for R* and C*
  (those arrays have 3 elements). When result is "Y", action is "none".

Return ONLY this JSON (no markdown, no extra text):

{
  "opportunity_id": "<id>",
  "matched_folder": "<folder>",
  "order_category": "Kit|Circuit|<other>",
  "required_information": [
    ["R1","Y|N","<reason>"], ["R2","Y|N","<reason>"], ["R3","Y|N","<reason>"],
    ["R4","Y|N","<reason>"], ["R5","Y|N","<reason>"], ["R6","Y|N","<reason>"],
    ["R7","Y|N","<reason>"]
  ],
  "checks": [
    ["C1","Y|N","<reason>"], ["C2","Y|N","<reason>"], ["C3","Y|N","<reason>"],
    ["C4","Y|N","<reason>"], ["C5","Y|N","<reason>"], ["C6","Y|N","<reason>"],
    ["C7","Y|N","<reason>"], ["C8","Y|N","<reason>"], ["C9","Y|N","<reason>"],
    ["C10","Y|N","<reason>"], ["C11","Y|N","<reason>"], ["C12","Y|N","<reason>"],
    ["C13","Y|N","<reason>"], ["C14","Y|N","<reason>"], ["C15","Y|N","<reason>"],
    ["C16","Y|N","<reason>"], ["C17","Y|N","<reason>"], ["C18","Y|N","<reason>"],
    ["C19","Y|N","<reason>"], ["C20","Y|N","<reason>"], ["C21","Y|N","<reason>"],
    ["C22","Y|N","<reason>"], ["C23","Y|N","<reason>"], ["C24","Y|N","<reason>"],
    ["C25","Y|N","<reason>"], ["C26","Y|N","<reason>"], ["C27","Y|N","<reason>"]
  ],
  "bsp_base_checks": [
    ["B1","Y|N","<reason>","<action>"], ["B2","Y|N","<reason>","<action>"],
    ["B3","Y|N","<reason>","<action>"], ["B4","Y|N","<reason>","<action>"],
    ["B5","Y|N","<reason>","<action>"], ["B6","Y|N","<reason>","<action>"],
    ["B7","Y|N","<reason>","<action>"], ["B8","Y|N","<reason>","<action>"],
    ["B9","Y|N","<reason>","<action>"], ["B10","Y|N","<reason>","<action>"],
    ["B11","Y|N","<reason>","<action>"], ["B13","Y|N","<reason>","<action>"],
    ["B12","Y|N","<reason>","<action>"]
  ],
  "circuit_checks": [
    ["X1","Y|N","<reason>","<action>"], ["X2","Y|N","<reason>","<action>"],
    ["X3","Y|N","<reason>","<action>"], ["X4","Y|N","<reason>","<action>"],
    ["X5","Y|N","<reason>","<action>"], ["X6","Y|N","<reason>","<action>"],
    ["X7","Y|N","<reason>","<action>"], ["X8","Y|N","<reason>","<action>"],
    ["X9","Y|N","<reason>","<action>"]
  ],
  "val_checks": [
    ["VAL-001","Y|N|NA","<reason>","<action>"], ["VAL-002","Y|N|NA","<reason>","<action>"],
    ["VAL-003","Y|N|NA","<reason>","<action>"], ["VAL-004","Y|N|NA","<reason>","<action>"],
    ["VAL-005","Y|N|NA","<reason>","<action>"], ["VAL-006","Y|N|NA","<reason>","<action>"],
    ["VAL-007","Y|N|NA","<reason>","<action>"], ["VAL-008","Y|N|NA","<reason>","<action>"],
    ["VAL-009","Y|N|NA","<reason>","<action>"], ["VAL-013","Y|N|NA","<reason>","<action>"],
    ["VAL-023","Y|N|NA","<reason>","<action>"], ["VAL-014","Y|N|NA","<reason>","<action>"],
    ["VAL-015","Y|N|NA","<reason>","<action>"], ["VAL-016","Y|N|NA","<reason>","<action>"],
    ["VAL-017","Y|N|NA","<reason>","<action>"], ["VAL-018","Y|N|NA","<reason>","<action>"],
    ["VAL-019","Y|N|NA","<reason>","<action>"], ["VAL-020","Y|N|NA","<reason>","<action>"],
    ["VAL-021","Y|N|NA","<reason>","<action>"], ["VAL-022","Y|N|NA","<reason>","<action>"]
  ],
  "overall": { "ready_for_order": "Y|N", "blocking_issues": ["..."], "needs_human_review": ["..."] }
}

- "val_checks" is REQUIRED for every order and must contain all 20 entries
  in the order listed. VAL-014..VAL-022 are "NA" for non-circuit orders.
- A single "N" in val_checks means ready_for_order is "N".

- INCLUDE "circuit_checks" ONLY when order_category is Circuit; for Kit /
  non-circuit orders omit the whole "circuit_checks" array.

ACTION values (element 3 of B* and X* arrays only):
- "Y" -> "none". "N" -> the correct owner:
  "raise_mdg"  (create/correct company or billing entity via MDG),
  "raise_bsp"  (create address/premise via the BSP Team),
  "raise_mdm"  (create/sync product code via MDM),
  "raise_sales"(back to sales - PO, pricing, expiry),
  "manual_correction" (fix a typo / mismatch), "none".
  These are defaults; a human can override in the UI. Keep the reasoning
  specific about what must be done.

Y/N rules:
- "Y" ONLY when the check is confirmed with evidence from the documents -
  name the source document in "notes".
- "N" when the item is missing, wrong, expired, or CANNOT be verified from
  the documents - explain why in "notes".
- If a check genuinely does not apply (e.g. C11 when the product is not
  DIA), answer "Y" and write "Not applicable - <reason>" in "notes", so it
  does not falsely block the order.
- Never answer "Y" without evidence.

IMPORTANT: Failed (N) checks do NOT stop the process. Always answer every
single check honestly, complete the full JSON, and finish. The next step
(BSP template extraction) will always run regardless of the validation
outcome. If the tool returned not_found / error / ambiguous, still return
the full JSON with every result "N" and the tool problem explained in the
notes and in blocking_issues.
"""

# ─────────────────────────────────────────────────────────────────────
# THE VALIDATION AGENT
# ─────────────────────────────────────────────────────────────────────
validation_agent = Agent(
    model=gemini_model,
    name="qto_validation_agent",
    # NOTE: `mode="single_turn"` was removed here. ADK's Agent is a Pydantic
    # model with extra="forbid" and has no `mode` field, so it raised
    # `extra_forbidden` at import time and the agent could never be built.
    # Single-turn behaviour is a property of how the agent is invoked (the
    # pipeline sends one message and reads the final response), not a
    # constructor option.
    description=(
        "Retrieves parsed documents for an opportunity id from GCS and runs "
        "the Vodafone quote-to-order validation checklist."
    ),
    instruction=VALIDATION_PROMPT,
    tools=[
        get_opportunity_data,
        lookup_bsp_company,
        lookup_bsp_location,
        save_validation_status,
        get_validation_status,
    ],
    output_key="validation_report",
)
