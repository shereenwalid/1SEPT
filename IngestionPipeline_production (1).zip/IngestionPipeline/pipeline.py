"""
pipeline.py — central router and orchestrator.

Production behaviors:
  - Run lock (GCS generation precondition) so an overlapping scheduled +
    manual run can never race on the state ledger.
  - State ledger v2: per-file object generation, attempt count, and status
    ("done" | "error" | "failed"). Legacy v1 ledgers (flat name->timestamp)
    are migrated transparently.
  - Change detection uses the GCS object *generation* (changes on every
    content overwrite), not just the updated timestamp.
  - Dead-lettering: a file that fails runtime.max_file_attempts times is
    parked with status "failed" and skipped until its content changes,
    instead of being retried (and re-billed) on every run forever.
  - Bounded parallelism (ThreadPoolExecutor) with a wall-clock budget so the
    Cloud Run Functions timeout never kills the process mid-write. Files
    that don't fit in the budget are deferred to the next run.
  - Incremental state persistence: after every batch and again in `finally`.

Flow:
  1. Optionally sync source bucket -> input bucket
  2. Acquire run lock
  3. List blobs, select pending (new / changed / retryable)
  4. Process in parallel batches, routing by extension
  5. Save outputs to GCS parsed_prefix, update ledger incrementally
  6. Release lock, return run summary
"""

import io
import json
import logging
import mimetypes
import posixpath
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote

from utils.config_loader import PipelineConfig
from utils.gcs_helper import GCSHelper
from utils.gemini_client import GeminiClient
from parsers.pdf_parser import PDFParser
from parsers.docx_parser import DOCXParser
from parsers.excel_parser import ExcelParser
from parsers.email_parser import EmailParser, Attachment
from parsers.image_parser import ImageParser
from parsers.pptx_parser import PPTXParser
from parsers.text_parser import TextParser
from parsers.visio_parser import VisioParser
from utils.opp_versions import OppFolder, find_opp_in_path, rank_versions
from utils.validation_step import (
    ValidationAgentUnavailable,
    ValidationRunner,
)

logger = logging.getLogger(__name__)

STATE_VERSION = 2


class IngestionPipeline:
    def __init__(self, config: PipelineConfig):
        self.cfg = config

        # Shared GCS helper for destination bucket operations
        self.gcs = GCSHelper(
            config.gcs.destination_project_id or config.gcp.project_id
        )
        self.source_gcs = (
            GCSHelper(
                config.gcs.source_project_id or config.gcp.project_id
            )
            if config.gcs.source_bucket
            else None
        )

        self.gemini = GeminiClient(
            project_id=config.llm.project_id,
            location=config.gcp.location,
            proxy_url=config.llm.proxy_url,
            model_name=config.gemini.model,
            temperature=config.gemini.temperature,
            max_output_tokens=config.gemini.max_output_tokens,
        )

        self.validator = (
            ValidationRunner(config, self.gcs)
            if getattr(getattr(config, "validation", None), "enabled", False)
            else None
        )

        # OPP version bookkeeping
        self._opp_newest: Dict[str, OppFolder] = {}
        self._opp_doc_newest: Dict[Tuple[str, str], OppFolder] = {}
        self._opp_pending_manifest: Dict[str, Dict[str, str]] = {}
        self._opp_lock = threading.Lock()
        self._preflighted = False
        self._dedup_map: Dict[str, str] = {}
        self._dedup_lock = threading.Lock()

        # Extension -> parser type map (resolved from config)
        self._ext_map: Dict[str, str] = {}
        for parser_type, extensions in config.supported_extensions.items():
            for ext in extensions:
                self._ext_map[ext.lower()] = parser_type

    # ------------------------------------------------------------------ run

    def run(
        self,
        limit: Optional[int] = None,
        dry_run: bool = False,
        folder: Optional[str] = None,
        force: bool = False,
        opp: Optional[str] = None,
        validate_only: bool = False,
    ) -> Dict[str, Any]:
        """Execute one pipeline pass. Returns a run summary.

        limit:   cap the number of files processed this run (ops/testing).
        dry_run: list what *would* be processed without touching anything.
        folder:  restrict BOTH the sync and the parse to one subfolder,
                 relative to the configured source/input prefixes. e.g.
                 folder="opp123" syncs gs://<src>/<source_prefix>opp123/
                 into gs://<dst>/<input_prefix>opp123/ and parses only
                 that subtree. Output paths are unaffected — they still
                 land under <input_prefix><parsed_prefix>opp123/...
        opp:     process only files belonging to this OPP id (e.g.
                 "OPP-0007724692"). Unlike `folder`, this follows the OPP
                 across its base folder AND every Modified-File version,
                 which is what you want to test one opportunity end to end.
        validate_only: skip parsing entirely and only run the validation
                 stage for the opportunities in scope. Cheap way to test or
                 re-run validation without re-billing document parsing.
        force:   ignore ledger status and reprocess everything in scope,
                 even files already marked done. Costs LLM calls again —
                 pair with `folder` and/or `limit` unless you really mean
                 the whole bucket.
        """
        cfg = self.cfg
        bucket = cfg.gcs.destination_bucket
        run_id = uuid.uuid4().hex[:8]
        started = time.monotonic()
        deadline = started + cfg.runtime.max_runtime_seconds

        # "" for a full run, or "opp123/" for a scoped one. The trailing
        # slash matters: without it, "opp1" would also match "opp123".
        scope = folder.strip("/") + "/" if folder and folder.strip("/") else ""

        summary: Dict[str, Any] = {
            "run_id": run_id,
            "status": "ok",
            "processed": [],
            "errors": [],
            "deferred": [],
            "dead_lettered": [],
            "skipped_no_parser": [],
            "validated": {},
        }

        opp_filter = opp.strip().upper() if opp else None
        if opp_filter:
            summary["opp_filter"] = opp_filter
            logger.info("[%s] Scoped run — OPP '%s' only", run_id, opp_filter)
        if force:
            summary["force"] = True
            logger.warning(
                "[%s] FORCE mode — reprocessing files already marked done",
                run_id,
            )
        if scope:
            summary["folder"] = scope
            logger.info("[%s] Scoped run — folder '%s' only", run_id, scope)

        # validate_only re-reads already-parsed output; syncing source
        # documents would be pure cost for no benefit.
        if (
            getattr(cfg.gcs, "sync_enabled", False)
            and cfg.gcs.source_bucket
            and not dry_run
            and not validate_only
        ):
            self._sync_source_bucket(
                source_bucket=cfg.gcs.source_bucket,
                source_prefix=cfg.gcs.source_prefix + scope,
                destination_bucket=bucket,
                destination_prefix=cfg.gcs.input_prefix + scope,
                name_filter=opp_filter,
            )
        elif validate_only:
            logger.info("[%s] validate-only: skipping source sync", run_id)
        elif not getattr(cfg.gcs, "sync_enabled", False):
            logger.info(
                "[%s] Source sync disabled — reading opportunity folders "
                "directly from gs://%s/%s", run_id, bucket, cfg.gcs.input_prefix,
            )

        lock_blob = posixpath.join(
            posixpath.dirname(cfg.state_tracker_blob), "run.lock"
        )
        lock_acquired = False
        if not dry_run:
            lock_acquired = self.gcs.acquire_run_lock(
                bucket, lock_blob, cfg.runtime.lock_lease_seconds
            )
            if not lock_acquired:
                logger.warning(
                    "[%s] Another run holds the lock — exiting without work",
                    run_id,
                )
                summary["status"] = "locked"
                return summary

        try:
            state = self._migrate_state(
                self.gcs.load_state(bucket, cfg.state_tracker_blob)
            )
            files: Dict[str, Any] = state["files"]
            # md5 -> output path, so identical content is parsed once ever.
            self._dedup_map = state.setdefault("content_hashes", {})

            # Scoped runs list only the subfolder. _output_path and the
            # own-output filter still use the BASE input_prefix, so parsed
            # files land in the usual place regardless of scoping.
            blobs = self.gcs.list_blobs(bucket, cfg.gcs.input_prefix + scope)

            if opp_filter:
                blobs = [
                    b for b in blobs
                    if self._blob_opp_id(b.name) == opp_filter
                    or b.name.startswith(
                        self._opp_dir(opp_filter)
                    )
                ]
                logger.info(
                    "[%s] OPP filter matched %d object(s)", run_id, len(blobs)
                )

            # Build the OPP version index from the FULL listing (not just
            # pending files) — deciding which version is newest requires
            # seeing every version, including ones already processed.
            self._build_opp_index(blobs, bucket, summary)
            pending, dead, no_parser = self._select_pending(
                blobs, files, force=force
            )
            summary["dead_lettered"] = dead
            summary["skipped_no_parser"] = no_parser

            logger.info(
                "[%s] Ledger entries=%d, pending=%d, dead-lettered=%d",
                run_id, len(files), len(pending), len(dead),
            )

            # Process ONE OPPORTUNITY AT A TIME, start to finish. An OPP's
            # files live in its base folder AND in every Modified-File
            # version, which sort far apart lexicographically — without this
            # grouping a single opportunity's files are scattered across the
            # whole run, so it isn't "done" (and can't be validated) until
            # near the end. Files with no OPP id are processed last.
            pending.sort(
                key=lambda b: (
                    self._blob_opp_id(b.name) or "\uffff",
                    b.name,
                )
            )

            if limit is not None:
                pending = pending[: max(0, int(limit))]

            if dry_run:
                summary["pending"] = [b.name for b in pending]
                return summary

            if validate_only:
                # Only opportunities that actually HAVE parsed output. An
                # unparsed OPP has no documents to check, so validating it
                # just burns an agent call and writes a misleading "N".
                out_root = cfg.gcs.input_prefix + cfg.gcs.parsed_prefix
                parsed_opps = set()
                for b in self.gcs.list_blobs(bucket, out_root):
                    base = b.name.rsplit("/", 1)[-1]
                    if base in ("validation.json", "_versions.json"):
                        continue
                    if "/archive/" in b.name:
                        continue
                    o = self._blob_opp_id(b.name)
                    if o:
                        parsed_opps.add(o)

                in_scope = {
                    o for o in (self._blob_opp_id(b.name) for b in blobs) if o
                }
                opps = sorted(in_scope & parsed_opps) if in_scope else sorted(parsed_opps)
                skipped = len(in_scope - parsed_opps) if in_scope else 0
                logger.info(
                    "[%s] validate-only: %d opportunity(ies) with parsed "
                    "output; %d skipped (nothing parsed yet)",
                    run_id, len(opps), skipped,
                )
            else:
                self._process_pending(
                    pending, files, state, bucket, deadline, summary, lock_blob
                )
                # Validation runs per OPPORTUNITY, after all of its documents
                # are parsed — the checks compare documents against each
                # other, so a per-file hook would run repeatedly on
                # incomplete data.
                # Incremental validation (inside _process_pending) already
                # handled most of these; only pick up stragglers, e.g. OPPs
                # whose files all errored or were deferred mid-batch.
                opps = sorted({
                    o for o in (
                        self._blob_opp_id(n) for n in summary["processed"]
                    ) if o and o not in summary["validated"]
                })

            self._run_validation(summary, bucket, deadline, opps)
        finally:
            if lock_acquired:
                try:
                    self._flush_opp_manifests(bucket)
                except Exception:
                    logger.exception("Failed to flush OPP manifests")
                try:
                    self.gcs.save_state(
                        bucket, cfg.state_tracker_blob, state, force=True
                    )
                except Exception:
                    logger.exception(
                        "[%s] Final state save failed — some progress may "
                        "be reprocessed next run", run_id,
                    )
                self.gcs.release_run_lock(bucket, lock_blob)

        summary["duration_seconds"] = round(time.monotonic() - started, 1)
        logger.info(
            "[%s] Pipeline done — processed=%d errors=%d deferred=%d in %ss",
            run_id,
            len(summary["processed"]),
            len(summary["errors"]),
            len(summary["deferred"]),
            summary["duration_seconds"],
        )
        return summary

    def _process_pending(
        self,
        pending: List[Any],
        files: Dict[str, Any],
        state: Dict[str, Any],
        bucket: str,
        deadline: float,
        summary: Dict[str, Any],
        lock_blob: str,
    ) -> None:
        cfg = self.cfg
        max_workers = max(1, cfg.runtime.max_workers)

        # Remaining un-parsed files per opportunity. An OPP is validated the
        # moment its last file lands, rather than waiting for the whole run
        # to finish — otherwise a long backfill produces no verdicts at all
        # until the very end (and none if it crashes first).
        opp_remaining: Dict[str, int] = {}
        if self.validator is not None:
            for b in pending:
                o = self._blob_opp_id(b.name)
                if o:
                    opp_remaining[o] = opp_remaining.get(o, 0) + 1

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            idx = 0
            while idx < len(pending):
                # Check the wall-clock budget *between* batches so we always
                # have time to persist state before Cloud Run kills us.
                if time.monotonic() >= deadline:
                    summary["deferred"] = [b.name for b in pending[idx:]]
                    logger.warning(
                        "Time budget (%ds) reached — deferring %d file(s) "
                        "to the next run",
                        cfg.runtime.max_runtime_seconds,
                        len(summary["deferred"]),
                    )
                    break

                batch = pending[idx: idx + max_workers]
                idx += len(batch)

                futures = {
                    pool.submit(self._process_one, b, bucket): b
                    for b in batch
                }
                for fut in as_completed(futures):
                    blob = futures[fut]
                    prev = files.get(blob.name) or {}
                    try:
                        fut.result()
                        files[blob.name] = {
                            "generation": str(blob.generation),
                            "updated": blob.updated.isoformat(),
                            "processed_at": datetime.now(
                                timezone.utc
                            ).isoformat(),
                            "status": "done",
                            "attempts": 0,
                        }
                        summary["processed"].append(blob.name)
                        logger.info("✓ %s", blob.name)
                    except Exception as exc:
                        attempts = int(prev.get("attempts", 0)) + 1
                        exhausted = attempts >= cfg.runtime.max_file_attempts
                        files[blob.name] = {
                            "generation": str(blob.generation),
                            "updated": blob.updated.isoformat(),
                            "status": "failed" if exhausted else "error",
                            "attempts": attempts,
                            "last_error": str(exc)[:500],
                        }
                        summary["errors"].append(
                            {
                                "file": blob.name,
                                "attempt": attempts,
                                "error": str(exc),
                            }
                        )
                        if exhausted:
                            logger.error(
                                "✗ %s — attempt %d/%d failed, DEAD-LETTERED "
                                "until its content changes: %s",
                                blob.name, attempts,
                                cfg.runtime.max_file_attempts, exc,
                            )
                        else:
                            logger.exception("✗ %s — %s", blob.name, exc)

                # Persist after every batch: a crash/timeout must not lose
                # the record of files already (expensively) processed.
                self.gcs.save_state(
                    bucket, cfg.state_tracker_blob, state,
                    min_interval=cfg.runtime.state_save_min_interval,
                )
                # Keep the lock lease fresh so a long run (e.g. backfill)
                # can't have its lock stolen as "stale" by a scheduled run.
                self.gcs.renew_run_lock(bucket, lock_blob)

                # Validate opportunities whose files are now all parsed.
                if opp_remaining:
                    for b in batch:
                        o = self._blob_opp_id(b.name)
                        if o and o in opp_remaining:
                            opp_remaining[o] -= 1
                    ready = [o for o, n in opp_remaining.items() if n <= 0]
                    for o in ready:
                        opp_remaining.pop(o, None)
                    if ready:
                        self._run_validation(summary, bucket, deadline, ready)

    # ------------------------------------------------------- state handling

    @staticmethod
    def _migrate_state(raw: Dict[str, Any]) -> Dict[str, Any]:
        """Accept both ledger formats.

        v1: {"path/file.pdf": "<updated isoformat>", ...}
        v2: {"version": 2, "files": {"path/file.pdf": {...}, ...}}
        """
        if not raw:
            return {"version": STATE_VERSION, "files": {}}
        if raw.get("version") == STATE_VERSION and isinstance(
            raw.get("files"), dict
        ):
            return raw

        files: Dict[str, Any] = {}
        for name, value in raw.items():
            if isinstance(value, str):
                files[name] = {
                    "updated": value,
                    "status": "done",
                    "attempts": 0,
                }
            elif isinstance(value, dict):
                files[name] = value
        logger.info("Migrated %d ledger entries from v1 format", len(files))
        return {"version": STATE_VERSION, "files": files}

    def _select_pending(
        self, blobs: List[Any], files: Dict[str, Any], force: bool = False
    ) -> Tuple[List[Any], List[str], List[str]]:
        """Decide what to (re)process.

        Returns (pending_blobs, dead_lettered_names, no_parser_names):
          - never seen                      -> pending
          - content changed (generation)   -> pending (attempts reset)
          - status "error"                 -> pending (retry budget left)
          - status "failed", unchanged     -> dead-lettered, skipped
          - status "done", unchanged       -> skipped
        """
        pending: List[Any] = []
        dead: List[str] = []
        no_parser: List[str] = []
        product_code_skipped = 0
        superseded_skipped = 0
        skip_superseded = getattr(self.cfg.gcs, "opp_grouping", False) and (
            # With archiving off there is nowhere for an older version's
            # output to go, and parsing it would only risk overwriting the
            # current one — so it is always skipped.
            not self._archive_enabled()
            or getattr(self.cfg.gcs, "parse_superseded_versions", False) is False
        )

        # The pipeline's own outputs live under the parsed prefix inside the
        # input prefix — never report those as "skipped". legacy_parsed_
        # prefixes covers outputs from a PREVIOUS parsed_prefix, so a
        # re-run into a fresh folder doesn't mistake the old JSON for input.
        own_output_prefixes = tuple(
            self.cfg.gcs.input_prefix + p
            for p in [self.cfg.gcs.parsed_prefix]
            + list(getattr(self.cfg.gcs, "legacy_parsed_prefixes", []) or [])
        )

        for b in blobs:
            if b.name.endswith("/"):
                continue
            if b.name.startswith(own_output_prefixes):
                continue
            # Product Code folders are synced from the source bucket but
            # intentionally never parsed — they're pass-through data.
            if self._is_product_code_path(b.name):
                product_code_skipped += 1
                continue
            if self._extension(b.name) not in self._ext_map:
                no_parser.append(b.name)
                continue
            # Superseded document versions: the parsed output would go
            # straight into archive/, which nothing reads (the validation
            # agent skips it, and the source file stays in the bucket). By
            # far the biggest cost saving — most files in a Modified-File
            # layout are older versions of something.
            if skip_superseded and self._is_superseded(b.name):
                superseded_skipped += 1
                continue

            entry = files.get(b.name)
            if force:
                # Explicit re-parse: ignore "done"/"failed" status entirely.
                if isinstance(entry, dict):
                    entry["attempts"] = 0
                    files[b.name] = entry
                pending.append(b)
                continue
            if entry is None:
                pending.append(b)
                continue
            if isinstance(entry, str):  # defensive: unmigrated v1 value
                entry = {"updated": entry, "status": "done", "attempts": 0}

            if self._blob_changed(b, entry):
                logger.info("Content changed, reprocessing: %s", b.name)
                # New content: forget the old attempt count.
                entry["attempts"] = 0
                files[b.name] = entry
                pending.append(b)
            elif entry.get("status") == "error":
                pending.append(b)
            elif entry.get("status") == "failed":
                dead.append(b.name)
            # else: done & unchanged -> skip

        if product_code_skipped:
            logger.info(
                "Excluded %d file(s) in Product Code folders from parsing "
                "(sync-only)", product_code_skipped,
            )
        if superseded_skipped:
            logger.info(
                "Skipped %d superseded document version(s) — only current "
                "versions are parsed (gcs.parse_superseded_versions=false)",
                superseded_skipped,
            )
        if no_parser:
            logger.warning(
                "%d file(s) skipped — no parser for their extension: %s",
                len(no_parser), ", ".join(no_parser[:20]),
            )

        return pending, dead, no_parser

    @staticmethod
    def _is_product_code_path(blob_name: str) -> bool:
        """True if any *folder* segment of the path is a Product Code
        folder. Matching is deliberately liberal: case-insensitive, tolerant
        of URL-encoding and separators — so 'ProductCode', 'Product Code',
        'Product%20Code', 'product_codes', 'PRODUCT-CODE' all match.
        A file merely *named* product_code.xlsx in a normal folder does not.
        """
        for segment in blob_name.split("/")[:-1]:  # folders only
            norm = re.sub(r"[^a-z0-9]", "", unquote(segment).lower())
            if "product" in norm and "code" in norm:
                return True
        return False

    @staticmethod
    def _blob_changed(blob: Any, entry: Dict[str, Any]) -> bool:
        stored_gen = entry.get("generation")
        if stored_gen:
            return str(blob.generation) != str(stored_gen)
        # Legacy entries only have the updated timestamp.
        return blob.updated.isoformat() != entry.get("updated")


    def _run_validation(
        self,
        summary: Dict[str, Any],
        bucket: str,
        deadline: float,
        opps: List[str],
    ) -> None:
        """Validate every opportunity touched by this run.

        Non-blocking by design: parsing results are already persisted, so a
        validation failure is recorded and never fails the run.
        """
        # Explicit about skipping — a silently missing validation.json is
        # hard to diagnose otherwise.
        if self.validator is None:
            logger.info(
                "[Validation] Skipped — validation.enabled is false in config"
            )
            return
        if not opps:
            logger.info(
                "[Validation] Skipped — no opportunities in scope. Files "
                "already marked done in the ledger are not re-validated; "
                "use --validate-only to validate without re-parsing."
            )
            return

        # Pre-flight: load the agent ONCE before validating anything. A
        # broken agent fails identically for every opportunity, so stop the
        # run here rather than writing hundreds of misleading "N" verdicts.
        # Parsing results are already saved; the finally block still
        # persists state and manifests on the way out.
        if getattr(self.cfg.validation, "fail_fast", True) and not self._preflighted:
            self.validator.preflight()
            self._preflighted = True
        logger.info("[Validation] %d opportunity(ies) to validate", len(opps))
        workers = max(1, int(getattr(self.cfg.validation, "max_workers", 2)))

        def _one(opp_id: str):
            return opp_id, self.validator.validate(
                opp_id, bucket, self._opp_dir(opp_id)
            )

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {}
            for opp in opps:
                if time.monotonic() >= deadline:
                    logger.warning(
                        "[Validation] Time budget reached — %d opportunity(ies) "
                        "deferred to the next run", len(opps) - len(futures),
                    )
                    break
                futures[pool.submit(_one, opp)] = opp

            for fut in as_completed(futures):
                opp = futures[fut]
                try:
                    _, payload = fut.result()
                    if payload:
                        summary["validated"][opp] = payload["validation"]["status"]
                except Exception as exc:
                    logger.exception("[Validation] %s errored: %s", opp, exc)
                    summary["validated"][opp] = "error"

    # ------------------------------------------------------ OPP versioning

    # Per-OPP manifest recording which source folder version produced each
    # file currently in the main directory. Written after every run so the
    # next run can demote superseded outputs exactly, without re-parsing.
    OPP_MANIFEST = "_versions.json"

    def _build_opp_index(
        self, blobs: List[Any], bucket: str, summary: Dict[str, Any]
    ) -> None:
        """Determine the newest folder version per OPP id, then move any
        now-superseded outputs from the main directory into archive/."""
        self._opp_newest = {}
        self._opp_doc_newest = {}
        if not getattr(self.cfg.gcs, "opp_grouping", False):
            return

        date_fmt = self.cfg.gcs.opp_date_format
        folders: Dict[str, OppFolder] = {}
        # Newest folder version that CONTAINS each individual document.
        # Versioning is per document, not per folder: a newer upload often
        # re-sends only some files, and the documents it omits are still
        # current — they must stay in the main directory, not be stranded
        # in archive/ where the validation agent can't see them.
        doc_newest: Dict[Tuple[str, str], OppFolder] = {}
        for b in blobs:
            found = find_opp_in_path(b.name, date_fmt)
            if not found:
                continue
            folder, inner = found
            if folder.raw not in folders:
                folders[folder.raw] = folder
            key = (folder.opp_id, self._doc_key(inner))
            cur = doc_newest.get(key)
            if cur is None or folder.version_key > cur.version_key:
                doc_newest[key] = folder
        self._opp_doc_newest = doc_newest

        ranked = rank_versions(list(folders.values()))
        for opp_id, versions in ranked.items():
            self._opp_newest[opp_id] = versions[0]
            if len(versions) > 1:
                logger.info(
                    "[OPP] %s — %d version(s), newest=%s",
                    opp_id, len(versions), versions[0].raw,
                )

        summary["opp_groups"] = {
            opp: {"newest": v[0].raw, "versions": len(v)}
            for opp, v in ranked.items() if len(v) > 1
        }
        self._archive_superseded(ranked, bucket, summary)

    def _blob_opp_id(self, blob_name: str) -> Optional[str]:
        """OPP id this blob belongs to, or None if it isn't in an OPP folder."""
        found = find_opp_in_path(
            blob_name, getattr(self.cfg.gcs, "opp_date_format", "DDMMYYYY")
        )
        return found[0].opp_id if found else None

    def _is_superseded(self, blob_name: str) -> bool:
        """True if a newer version of this same document exists elsewhere."""
        found = find_opp_in_path(blob_name, self.cfg.gcs.opp_date_format)
        if not found:
            return False
        folder, inner = found
        newest = self._opp_doc_newest.get(
            (folder.opp_id, self._doc_key(inner))
        )
        return newest is not None and folder.version_key < newest.version_key

    @staticmethod
    def _doc_key(inner: str) -> str:
        """Identity of a document across versions: its path inside the OPP
        folder, case-insensitive. Two folder versions containing the same
        filename are two versions of one document."""
        return inner.strip("/").lower()

    def _archive_enabled(self) -> bool:
        """Keep superseded versions under archive/? When false the OPP folder
        holds only the latest version of each document."""
        return bool(getattr(self.cfg.gcs, "opp_archive_versions", False))

    def _opp_dir(self, opp_id: str) -> str:
        cfg = self.cfg.gcs
        return cfg.input_prefix + cfg.parsed_prefix + opp_id + "/"

    def _archive_superseded(
        self,
        ranked: Dict[str, List[OppFolder]],
        bucket: str,
        summary: Dict[str, Any],
    ) -> None:
        """Move main-directory outputs into archive/ when a newer source
        version has appeared.

        The manifest records exactly which version each main-dir file came
        from, so files are MOVED (copy+delete, no LLM cost) rather than
        re-parsed. A file is demoted only when a newer version OF THAT SAME
        DOCUMENT exists — not merely because a newer folder version arrived
        (that newer upload may not have re-sent this document at all).
        """
        if not self._archive_enabled():
            # Nothing is demoted; anything already sitting in archive/ from a
            # previous configuration is promoted back so the OPP folder is
            # complete.
            self._promote_stranded(ranked, bucket, summary)
            return

        moved = 0
        for opp_id, versions in ranked.items():
            opp_dir = self._opp_dir(opp_id)
            manifest = self._load_opp_manifest(bucket, opp_dir)
            if not manifest:
                continue  # nothing recorded yet — nothing to demote

            keep: Dict[str, str] = {}
            for rel, tag in manifest.items():
                doc_newest = self._opp_doc_newest.get(
                    (opp_id, self._doc_key(self._strip_output_suffix(rel)))
                )
                if doc_newest is None or tag == doc_newest.suffix:
                    keep[rel] = tag          # still the newest of this doc
                    continue
                src = opp_dir + rel
                head, _, base = rel.rpartition("/")
                dst = opp_dir + "archive/" + (f"{head}/" if head else "") \
                    + self._archive_name(base, tag)
                try:
                    if self.gcs.move_blob(bucket, src, dst):
                        moved += 1
                        logger.info(
                            "[OPP] %s: archived superseded %s (version %s)",
                            opp_id, rel, tag,
                        )
                except Exception:
                    logger.exception("[OPP] Could not archive %s", src)
                    keep[rel] = tag   # leave the manifest entry intact

            if keep != manifest:
                self._save_opp_manifest(bucket, opp_dir, keep)

        if moved:
            summary["opp_archived"] = moved
            logger.info("[OPP] Archived %d superseded output(s)", moved)

        self._promote_stranded(ranked, bucket, summary)

    def _promote_stranded(
        self,
        ranked: Dict[str, List[OppFolder]],
        bucket: str,
        summary: Dict[str, Any],
    ) -> None:
        """Move archived files back to the main directory when nothing in
        main supersedes them.

        Repairs output written under the earlier folder-level rule, where a
        document was archived just because a newer FOLDER version existed —
        even if that newer version never contained the document. Those files
        are the current version of that document and belong in main, where
        the validation agent can see them.
        """
        promoted = 0
        for opp_id in ranked:
            opp_dir = self._opp_dir(opp_id)
            archive_prefix = opp_dir + "archive/"

            main_docs = set()
            for b in self.gcs.list_blobs(bucket, opp_dir):
                rel = b.name[len(opp_dir):]
                if rel.startswith("archive/") or not rel:
                    continue
                if rel in ("validation.json", "_versions.json"):
                    continue
                main_docs.add(self._doc_key(self._strip_output_suffix(rel)))

            manifest = self._load_opp_manifest(bucket, opp_dir)
            best: Dict[str, Any] = {}
            for b in self.gcs.list_blobs(bucket, archive_prefix):
                rel = b.name[len(archive_prefix):]
                if not rel:
                    continue
                doc, tag = self._split_archive_name(rel)
                key = self._doc_key(self._strip_output_suffix(doc))
                if key in main_docs:
                    continue  # a current version already sits in main
                prev = best.get(key)
                if prev is None or (tag or "") > (prev[1] or ""):
                    best[key] = (b.name, tag, doc)

            for key, (src, tag, doc) in best.items():
                dst = opp_dir + doc
                try:
                    if self.gcs.move_blob(bucket, src, dst):
                        promoted += 1
                        manifest[doc] = tag or ""
                        logger.info(
                            "[OPP] %s: promoted %s from archive — no newer "
                            "version of this document exists", opp_id, doc,
                        )
                except Exception:
                    logger.exception("[OPP] Could not promote %s", src)

            if best:
                self._save_opp_manifest(bucket, opp_dir, manifest)

        if promoted:
            summary["opp_promoted"] = promoted
            logger.info(
                "[OPP] Promoted %d stranded archive file(s) back to main",
                promoted,
            )

    @staticmethod
    def _split_archive_name(rel: str):
        """Inverse of _archive_name: 'spec.pdf_8461_05082026_1114.json'
        -> ('spec.pdf.json', '8461_05082026_1114')."""
        for suffix in ("_extracted.json", ".json"):
            if rel.endswith(suffix):
                stem = rel[: -len(suffix)]
                # tag is the trailing batch/date/time component(s)
                m = re.search(r"_(\d+(?:_\d{8}_\d{4})?)$", stem)
                if m:
                    return stem[: m.start()] + suffix, m.group(1)
                return rel, None
        return rel, None

    @staticmethod
    def _strip_output_suffix(rel: str) -> str:
        """Recover the source document path from an output filename:
        'spec.pdf.json' -> 'spec.pdf', 'data.xlsx_extracted.json' -> 'data.xlsx'."""
        for suffix in ("_extracted.json", ".json"):
            if rel.endswith(suffix):
                return rel[: -len(suffix)]
        return rel

    @staticmethod
    def _archive_name(rel: str, tag: str) -> str:
        """Insert the version tag before the output suffix, so the original
        filename stays intact and versions never collide:
            tecspec.pdf.json           -> tecspec.pdf_<tag>.json
            data.xlsx_extracted.json   -> data.xlsx_<tag>_extracted.json
        Used by BOTH parse-time archiving and move-time demotion so the two
        always agree on a file's archived name.
        """
        for suffix in ("_extracted.json", ".json"):
            if rel.endswith(suffix):
                return f"{rel[: -len(suffix)]}_{tag}{suffix}"
        return f"{rel}_{tag}"

    def _load_opp_manifest(self, bucket: str, opp_dir: str) -> Dict[str, str]:
        try:
            raw = self.gcs.download_bytes(bucket, opp_dir + self.OPP_MANIFEST)
            data = json.loads(raw)
            return data.get("files", {}) if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _save_opp_manifest(
        self, bucket: str, opp_dir: str, files: Dict[str, str]
    ) -> None:
        try:
            self.gcs.upload_json(
                bucket,
                opp_dir + self.OPP_MANIFEST,
                {
                    "files": files,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                },
            )
        except Exception:
            logger.exception("[OPP] Could not save manifest for %s", opp_dir)

    def _record_opp_output(self, out_path: str, blob_name: str) -> None:
        """Note that out_path (a main-dir output) came from blob_name's
        folder version. Flushed to the manifests at end of run."""
        if not getattr(self.cfg.gcs, "opp_grouping", False):
            return
        found = find_opp_in_path(blob_name, self.cfg.gcs.opp_date_format)
        if not found:
            return
        folder, _ = found
        opp_dir = self._opp_dir(folder.opp_id)
        if not out_path.startswith(opp_dir) or "/archive/" in out_path:
            return  # archived copies aren't tracked as "current"
        with self._opp_lock:
            self._opp_pending_manifest.setdefault(opp_dir, {})[
                out_path[len(opp_dir):]
            ] = folder.suffix

    def _flush_opp_manifests(self, bucket: str) -> None:
        """Merge this run's recorded outputs into the per-OPP manifests."""
        with self._opp_lock:
            pending = dict(self._opp_pending_manifest)
            self._opp_pending_manifest.clear()
        for opp_dir, files in pending.items():
            merged = self._load_opp_manifest(bucket, opp_dir)
            merged.update(files)
            self._save_opp_manifest(bucket, opp_dir, merged)

    def _process_one(self, blob, bucket: str) -> None:
        """Dedup check, then normal parse."""
        if self._try_dedup(blob, bucket):
            return
        self._process_blob(blob.name, bucket)

    def _try_dedup(self, blob, bucket: str) -> bool:
        """If an identical file was already parsed, copy its output instead
        of calling the LLM again.

        Modified-File uploads typically re-send an entire folder with one
        document changed, so the same bytes are parsed many times. GCS
        provides an MD5 per object, so duplicates are free to detect.
        """
        if not getattr(self.cfg.runtime, "dedup_identical_files", True):
            return False
        md5 = getattr(blob, "md5_hash", None)
        if not md5:
            return False

        suffix = self._suffix_for(blob.name)
        out_path = self._output_path(blob.name, suffix)

        with self._dedup_lock:
            seen = self._dedup_map.get(md5)
        if not seen or seen == out_path:
            with self._dedup_lock:
                self._dedup_map.setdefault(md5, out_path)
            return False

        try:
            if self.gcs.copy_blob_within(bucket, seen, out_path):
                logger.info(
                    "≡ %s — identical content already parsed, copied output "
                    "(no LLM call)", blob.name,
                )
                self._record_opp_output(out_path, blob.name)
                return True
        except Exception:
            logger.warning(
                "Dedup copy failed for %s; parsing normally", blob.name
            )
        return False

    def _suffix_for(self, name: str) -> str:
        return (
            "_extracted.json"
            if self._ext_map.get(self._extension(name)) == "excel"
            else ".json"
        )

    def _process_blob(self, blob_name: str, bucket: str) -> None:
        ext = self._extension(blob_name)
        parser_type = self._ext_map.get(ext)
        filename = PurePosixPath(blob_name).name

        logger.info("Processing [%s] %s", parser_type, blob_name)
        file_bytes = self.gcs.download_bytes(bucket, blob_name)
        self._route(parser_type, file_bytes, filename, blob_name, bucket)

    def _route(
        self,
        parser_type: Optional[str],
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        zip_depth: int = 0,
        mime_type: Optional[str] = None,
    ) -> None:
        """Single dispatch point used for top-level blobs, email
        attachments, and zip archive entries alike.

        mime_type: authoritative content type when the caller knows it
        (email attachments carry one in their headers). Falls back to
        guessing from the filename."""
        if parser_type == "pdf":
            self._handle_pdf(file_bytes, filename, blob_name, bucket)
        elif parser_type == "docx":
            self._handle_docx(file_bytes, filename, blob_name, bucket)
        elif parser_type == "excel":
            self._handle_excel(file_bytes, filename, blob_name, bucket)
        elif parser_type == "email":
            self._handle_email(file_bytes, filename, blob_name, bucket)
        elif parser_type == "image":
            self._handle_image(
                file_bytes, filename, blob_name, bucket,
                mime_type or self._guess_mime(filename),
            )
        elif parser_type == "text":
            self._handle_text(file_bytes, filename, blob_name, bucket)
        elif parser_type == "pptx":
            self._handle_pptx(file_bytes, filename, blob_name, bucket)
        elif parser_type == "visio":
            self._handle_visio(file_bytes, filename, blob_name, bucket)
        elif parser_type == "archive":
            self._handle_zip(
                file_bytes, filename, blob_name, bucket, depth=zip_depth
            )
        else:
            logger.warning(
                "No parser for '%s' — skipping %s", filename, blob_name
            )

    # ---- archives ------------------------------------------------------

    MAX_ZIP_DEPTH = 2          # zip inside zip is the limit
    MAX_ZIP_ENTRIES = 500      # per archive
    MAX_ENTRY_BYTES = 100 * 1024 * 1024  # per uncompressed entry

    def _handle_zip(
        self,
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        depth: int = 0,
    ) -> None:
        """Extract a zip and route every contained file through its own
        parser. Outputs land under <zipname>_extracted/<inner path> in the
        parsed prefix. If any entry fails, the zip as a whole is treated as
        failed so the ledger's retry/dead-letter semantics apply to it
        (re-runs are idempotent — successful entries just overwrite)."""
        import zipfile

        if depth >= self.MAX_ZIP_DEPTH:
            logger.warning(
                "[Zip] %s exceeds max nesting depth (%d) — not extracting",
                blob_name, self.MAX_ZIP_DEPTH,
            )
            return

        archive_root = posixpath.join(
            posixpath.dirname(blob_name),
            PurePosixPath(filename).name + "_extracted",
        )
        failures: List[str] = []
        routed = 0

        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            entries = [i for i in zf.infolist() if not i.is_dir()]
            if len(entries) > self.MAX_ZIP_ENTRIES:
                logger.warning(
                    "[Zip] %s has %d entries — only the first %d are processed",
                    blob_name, len(entries), self.MAX_ZIP_ENTRIES,
                )
                entries = entries[: self.MAX_ZIP_ENTRIES]

            for info in entries:
                inner = info.filename
                base = posixpath.basename(inner)
                if inner.startswith("__MACOSX/") or base.startswith("."):
                    continue
                if info.file_size > self.MAX_ENTRY_BYTES:
                    logger.warning(
                        "[Zip] Skipping oversized entry %s (%d bytes) in %s",
                        inner, info.file_size, blob_name,
                    )
                    continue

                ptype = self._ext_map.get(self._extension(inner))
                virtual_blob = posixpath.join(archive_root, inner)
                if ptype is None:
                    logger.warning(
                        "[Zip] No parser for entry %s in %s — skipped",
                        inner, blob_name,
                    )
                    continue

                logger.info("  [Zip entry:%s] %s", ptype, inner)
                try:
                    self._route(
                        ptype, zf.read(info), base, virtual_blob, bucket,
                        zip_depth=depth + 1,
                    )
                    routed += 1
                except Exception as exc:
                    logger.exception(
                        "  [Zip entry] %s in %s failed: %s",
                        inner, blob_name, exc,
                    )
                    failures.append(f"{inner}: {exc}")

        logger.info(
            "[Zip] %s — %d entrie(s) parsed, %d failed",
            blob_name, routed, len(failures),
        )
        if failures:
            raise RuntimeError(
                f"{len(failures)} entrie(s) failed inside {filename}: "
                + "; ".join(failures[:5])
            )

    def _save_output(
        self, bucket: str, out_path: str, blob_name: str, payload: Any
    ) -> None:
        """Upload a parsed result and record which OPP source version it
        came from (used to archive it when a newer version arrives)."""
        self.gcs.upload_json(bucket, out_path, payload)
        self._record_opp_output(out_path, blob_name)

    def _handle_pdf(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = PDFParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    def _handle_text(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = TextParser()
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    def _handle_docx(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = DOCXParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    def _handle_excel(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = ExcelParser(
            gemini=self.gemini,
            max_cells_for_gemini=self.cfg.excel.max_cells_for_gemini,
        )
        summary = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, "_extracted.json")
        self._save_output(bucket, out_path, blob_name, summary)

    def _handle_email(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = EmailParser(self.gemini)
        result, attachments = parser.parse(file_bytes, filename)

        # Save email extraction
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

        # Route attachments recursively through their own parsers
        for att in attachments:
            try:
                self._process_attachment(att, blob_name, bucket)
            except Exception as exc:
                logger.warning(
                    "Attachment %s from %s failed: %s",
                    att.filename, filename, exc,
                )

    def _handle_image(
        self,
        file_bytes: bytes,
        filename: str,
        blob_name: str,
        bucket: str,
        mime_type: str,
    ) -> None:
        parser = ImageParser(self.gemini)
        result = parser.parse(
            image_bytes=file_bytes,
            filename=filename,
            mime_type=mime_type,
        )
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    def _handle_pptx(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = PPTXParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    def _handle_visio(
        self, file_bytes: bytes, filename: str, blob_name: str, bucket: str
    ) -> None:
        parser = VisioParser(self.gemini)
        result = parser.parse(file_bytes, filename)
        out_path = self._output_path(blob_name, ".json")
        self._save_output(bucket, out_path, blob_name, result)

    @staticmethod
    def _ignore_attachment(filename: str) -> bool:
        return "logo" in filename.lower()

    def _process_attachment(
        self, att: Attachment, parent_blob: str, bucket: str
    ) -> None:
        """Route an email attachment to the correct parser."""
        if self._ignore_attachment(att.filename):
            logger.info("    Skipping logo attachment %s", att.filename)
            return

        ext = self._extension(att.filename)
        parser_type = self._ext_map.get(ext)

        # Virtual blob name for output path calculation. Namespaced by the
        # SOURCE EMAIL — a shared "attachments/" folder per directory meant
        # same-named attachments (invoice.pdf, image001.png) from different
        # emails silently overwrote each other.
        virtual_blob = posixpath.join(
            posixpath.dirname(parent_blob),
            PurePosixPath(parent_blob).name + "_attachments",
            att.filename,
        )

        logger.info("    Attachment [%s] %s", parser_type, att.filename)
        # Use the attachment's declared MIME type — more reliable than
        # guessing from a filename like "image001.png" or "attachment".
        self._route(
            parser_type, att.data, att.filename, virtual_blob, bucket,
            mime_type=att.mime_type,
        )

    # --------------------------------------------------------------- utils

    def _output_path(self, blob_name: str, new_suffix: str) -> str:
        """
        Put parsed output in a parsed_prefix subfolder alongside the input.

        The FULL original filename (extension included) is kept in the
        output name, because stripping it caused silent overwrites:
        report.pdf, report.docx and report.msg all used to map to the same
        report.json — last (parallel!) writer won.

        When the input sits inside an OPP folder (and opp_grouping is on),
        outputs are consolidated per OPP id, newest version in the main
        directory and older versions under archive/:

          .../8461_OPP-123_1114/spec.pdf
          .../Modified-File/8461_OPP-123_06082026_1217/spec.pdf
            -> parsed/OPP-123/spec.pdf.json                     (newest)
            -> parsed/OPP-123/archive/spec.pdf_8461_1114.json   (older)

        Otherwise the input's own path is mirrored, as before.
        """
        cfg = self.cfg.gcs
        rel = blob_name[len(cfg.input_prefix):]  # strip leading prefix

        if getattr(cfg, "opp_grouping", False):
            opp_path = self._opp_output_rel(blob_name, new_suffix)
            if opp_path is not None:
                return cfg.input_prefix + cfg.parsed_prefix + opp_path

        return cfg.input_prefix + cfg.parsed_prefix + rel + new_suffix

    def _opp_output_rel(
        self, blob_name: str, new_suffix: str
    ) -> Optional[str]:
        """Output path relative to parsed_prefix for an OPP-folder file, or
        None if this blob isn't inside an OPP folder."""
        found = find_opp_in_path(blob_name, self.cfg.gcs.opp_date_format)
        if not found:
            return None
        folder, inner = found

        # Is this the newest version OF THIS DOCUMENT (not of the folder)?
        newest = self._opp_doc_newest.get(
            (folder.opp_id, self._doc_key(inner))
        )
        is_newest = newest is None or folder.version_key >= newest.version_key

        if is_newest or not self._archive_enabled():
            # Archiving off: every version writes to the same path, so a
            # newer Modified-File version simply overwrites the older one.
            # Superseded versions are skipped before this point (see
            # _select_pending), so an older version can never land last and
            # clobber a newer one.
            return f"{folder.opp_id}/{inner}{new_suffix}"

        # Archived: tag with batch + stamp so versions never collide.
        head, _, base = inner.rpartition("/")
        stamped = self._archive_name(base + new_suffix, folder.suffix)
        return (
            f"{folder.opp_id}/archive/{head}/{stamped}" if head
            else f"{folder.opp_id}/archive/{stamped}"
        )

    def _sync_source_bucket(
        self,
        source_bucket: str,
        source_prefix: str,
        destination_bucket: str,
        destination_prefix: str,
        name_filter: Optional[str] = None,
    ) -> None:
        """Copy new/updated objects from the source bucket into the input bucket."""
        source_prefix = source_prefix or ""
        destination_prefix = destination_prefix or ""

        logger.info(
            "Syncing source bucket gs://%s/%s into gs://%s/%s",
            source_bucket,
            source_prefix or "(root)",
            destination_bucket,
            destination_prefix or "(root)",
        )

        if self.source_gcs is None:
            raise RuntimeError("Source GCS helper is not configured")

        self.source_gcs.copy_blobs(
            source_bucket,
            source_prefix,
            destination_bucket,
            destination_prefix,
            name_filter=name_filter,
        )

    @staticmethod
    def _guess_mime(filename: str) -> str:
        return mimetypes.guess_type(filename)[0] or "application/octet-stream"

    @staticmethod
    def _extension(name: str) -> str:
        return ("." + name.rsplit(".", 1)[-1]).lower() if "." in name else ""
