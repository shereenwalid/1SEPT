"""
retry_errors.py — re-parse ONLY the files that failed for a specific reason.

Use case: images were rejected by the LLM proxy ("image_input_not_permitted")
and now image input has been enabled. Rather than re-parsing all ~29k files
with --force, this finds the affected outputs, removes just those entries
from the ledger, and the next normal run reprocesses exactly those files.

Usage:
  python retry_errors.py --dry-run                 # show what would be retried
  python retry_errors.py                           # default: blocked images
  python retry_errors.py --error-code parse_error  # some other recorded error
  python retry_errors.py --opp OPP-0007724692      # limit to one opportunity

Then simply:
  python backfill.py

Read-only until you drop --dry-run; the only mutation is removing ledger
entries (and optionally deleting the stale placeholder outputs).
"""

import argparse
import json
import re
import sys
from urllib.parse import unquote

import yaml

DEFAULT_ERROR = "image_input_not_permitted"


def opp_of(path: str):
    m = re.search(r"(OPP-\d+)", unquote(path), re.IGNORECASE)
    return m.group(1).upper() if m else None


def strip_output_suffix(name: str) -> str:
    for suffix in ("_extracted.json", ".json"):
        if name.endswith(suffix):
            return name[: -len(suffix)]
    return name


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--error-code", default=DEFAULT_ERROR,
                    help=f"error value to retry (default: {DEFAULT_ERROR})")
    ap.add_argument("--opp", default=None, help="limit to one opportunity id")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--delete-outputs", action="store_true",
                    help="also delete the placeholder JSON outputs")
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config, encoding="utf-8"))
    bucket_name = cfg["gcs"]["destination_bucket"]
    input_prefix = cfg["gcs"]["input_prefix"]
    parsed_prefix = cfg["gcs"]["parsed_prefix"]
    state_blob = cfg["state"]["tracker_blob"]

    from google.cloud import storage
    client = storage.Client(
        project=cfg["gcs"].get("destination_project_id")
        or cfg["gcp"]["project_id"]
    )
    bucket = client.bucket(bucket_name)

    out_root = input_prefix + parsed_prefix
    print(f"Scanning gs://{bucket_name}/{out_root} for '{args.error_code}' ...")

    hits = []           # (output_blob, source_doc_name)
    for blob in bucket.list_blobs(prefix=out_root):
        if not blob.name.endswith(".json"):
            continue
        base = blob.name.rsplit("/", 1)[-1]
        if base in ("validation.json", "_versions.json"):
            continue
        if args.opp and opp_of(blob.name) != args.opp.upper():
            continue
        # Placeholder records are tiny; skip large files without downloading.
        if blob.size and blob.size > 20000:
            continue
        try:
            data = json.loads(blob.download_as_bytes())
        except Exception:
            continue
        if isinstance(data, dict) and data.get("error") == args.error_code:
            src = strip_output_suffix(base)
            hits.append((blob.name, src))

    print(f"  {len(hits)} output(s) recorded '{args.error_code}'")
    if not hits:
        return 0

    # Ledger: drop entries for the corresponding source files so they are
    # treated as new on the next run.
    raw = bucket.blob(state_blob).download_as_bytes()
    state = json.loads(raw)
    files = state.get("files", state)

    wanted = {src for _, src in hits}
    to_clear = [name for name in files
                if name.rsplit("/", 1)[-1] in wanted
                and (not args.opp or opp_of(name) == args.opp.upper())]

    print(f"  {len(to_clear)} ledger entry(ies) would be cleared")
    for n in to_clear[:15]:
        print(f"    {n}")
    if len(to_clear) > 15:
        print(f"    ... and {len(to_clear) - 15} more")

    if args.dry_run:
        print("\nDry run — nothing changed. Re-run without --dry-run to apply.")
        return 0

    for n in to_clear:
        files.pop(n, None)
    if "files" in state:
        state["files"] = files
    bucket.blob(state_blob).upload_from_string(
        json.dumps(state, indent=2).encode(), content_type="application/json"
    )
    print(f"\n  Ledger updated ({len(to_clear)} entry(ies) removed)")

    if args.delete_outputs:
        for out_name, _ in hits:
            try:
                bucket.blob(out_name).delete()
            except Exception:
                pass
        print(f"  Deleted {len(hits)} placeholder output(s)")

    print("\nNow run:  python backfill.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
