#!/usr/bin/env bash
# =============================================================
#  deploy.sh — one-shot deployment to Cloud Run Functions
#
#  Prerequisites:
#    gcloud CLI authenticated
#    APIs enabled: cloudfunctions, cloudscheduler,
#                  aiplatform, storage
#
#  Usage:
#    chmod +x deploy.sh
#    ./deploy.sh
# =============================================================

set -euo pipefail

if command -v yq &>/dev/null; then
  PROJECT_ID=$(yq '.gcp.project_id' config.yaml)
  LOCATION=$(yq '.gcp.location' config.yaml)
  CRON=$(yq '.scheduler.cron' config.yaml)
  TIMEZONE=$(yq '.scheduler.timezone' config.yaml)
else
  echo "   yq not found — reading env vars instead"
  PROJECT_ID="${GCP_PROJECT_ID:?Set GCP_PROJECT_ID}"
  LOCATION="${GCP_LOCATION:-europe-west1}"
  CRON="${SCHEDULER_CRON:-0 8 * * *}"
  TIMEZONE="${SCHEDULER_TZ:-Europe/Dublin}"
fi

FUNCTION_NAME="data-ingestion-pipeline"
SCHEDULER_JOB="trigger-${FUNCTION_NAME}"

echo "  Project  : $PROJECT_ID"
echo "  Location : $LOCATION"
echo "  Function : $FUNCTION_NAME"
echo "  Schedule : $CRON ($TIMEZONE)"

# Deploy the Cloud Run Function
gcloud functions deploy "$FUNCTION_NAME" \
  --gen2 \
  --project="$PROJECT_ID" \
  --region="$LOCATION" \
  --runtime=python312 \
  --trigger-http \
  --entry-point=main \
  --source=. \
  --memory=2Gi \
  --cpu=1 \
  --timeout=540s \
  --min-instances=0 \
  --max-instances=10 \
  --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID}" \
  --no-allow-unauthenticated   # Cloud Scheduler uses a service account

echo "  Function deployed"

#  Retrieve the function URL
FUNCTION_URL=$(
  gcloud functions describe "$FUNCTION_NAME" \
    --gen2 \
    --project="$PROJECT_ID" \
    --region="$LOCATION" \
    --format="value(serviceConfig.uri)"
)
echo "  Function URL: $FUNCTION_URL"

# Service account for Scheduler
SCHEDULER_SA="scheduler-invoker@${PROJECT_ID}.iam.gserviceaccount.com"

# Create service account if it doesn't exist
gcloud iam service-accounts describe "$SCHEDULER_SA" \
  --project="$PROJECT_ID" &>/dev/null \
  || gcloud iam service-accounts create scheduler-invoker \
       --display-name="Cloud Scheduler > Cloud Run invoker" \
       --project="$PROJECT_ID"

# Grant it permission to invoke the function
gcloud functions add-invoker-policy-binding "$FUNCTION_NAME" \
  --gen2 \
  --project="$PROJECT_ID" \
  --region="$LOCATION" \
  --member="serviceAccount:${SCHEDULER_SA}"

# Cloud Scheduler job — daily at 08:00 Europe/Dublin 
gcloud scheduler jobs describe "$SCHEDULER_JOB" \
  --project="$PROJECT_ID" \
  --location="$LOCATION" &>/dev/null \
  && ACTION="update" || ACTION="create"

gcloud scheduler jobs "$ACTION" http "$SCHEDULER_JOB" \
  --project="$PROJECT_ID" \
  --location="$LOCATION" \
  --schedule="$CRON" \
  --time-zone="$TIMEZONE" \
  --uri="${FUNCTION_URL}/run" \
  --http-method=GET \
  --oidc-service-account-email="$SCHEDULER_SA" \
  --oidc-token-audience="$FUNCTION_URL"

echo "  Scheduler job '${SCHEDULER_JOB}' ${ACTION}d (${CRON} ${TIMEZONE})"
echo ""
echo " Deployment complete!"
echo " Trigger URL : ${FUNCTION_URL}/run"
echo " Health URL  : ${FUNCTION_URL}/health"
