"""View 4: Results - Sales Order (BSP header) + Sales Order Rows (line items) tabs.

Sales Order tab: grouped sections (hero title strip, General, Parties & Billing,
Contacts, Dates & References, Description) instead of a flat grid of boxes.
Sales Order Rows tab: taller table (min 520px) so lines are comfortably visible.

Self-contained: the script hooks renderResults() after the main controller
loads, so app.py needs NO changes.
"""


def _dl_row(key: str, label: str) -> str:
    """One label/value row inside a section card."""
    return f"""
        <div class="flex items-start justify-between gap-4 px-4 py-2.5 border-b border-gray-100 last:border-b-0">
          <span class="font-label-sm text-[10px] text-secondary uppercase tracking-wider pt-0.5 shrink-0">{label}</span>
          <span class="text-[13px] font-medium text-on-surface text-right break-words" data-bsp="{key}">-</span>
        </div>"""


def _section(title: str, icon: str, rows: str) -> str:
    """A section card with a dark header strip (matches the app's panels)."""
    return f"""
      <section class="bg-white border border-gray-200 rounded-DEFAULT shadow-sm overflow-hidden flex flex-col">
        <div class="bg-gray-50 px-4 py-2 flex items-center gap-2 border-b border-gray-200">
          <span class="material-symbols-outlined text-primary text-[16px]">{icon}</span>
          <h3 class="text-[11px] uppercase tracking-wider text-gray-600 font-bold" style="font-family:'JetBrains Mono',monospace;">{title}</h3>
        </div>
        <div class="flex flex-col h-[176px] overflow-y-auto custom-scrollbar"
             style="scrollbar-width:thin; scrollbar-color:#c8c6c6 #f3f3f3;">{rows}</div>
      </section>"""


def _sales_order_panel() -> str:
    general = (_dl_row("external_reference_number", "External Reference (Opp ID)")
               + _dl_row("order_date", "Order Date")
               + _dl_row("location_count", "Location Count")
               + _dl_row("device_services", "Device Services"))
    parties = (_dl_row("company_code", "Company Code")
               + _dl_row("bill_to_party", "Bill To Party")
               + _dl_row("ship_to_party", "Ship To Party"))
    contacts = (_dl_row("customer_contact", "Customer Contact")
                + _dl_row("sales_contact", "Sales Contact")
                + _dl_row("account_manager", "Account Manager"))
    dates_refs = (_dl_row("contract_signed_date", "Contract Signed Date")
                  + _dl_row("customer_required_date", "Customer Required Date")
                  + _dl_row("customer_reference", "Customer Reference")
                  + _dl_row("escalation_level_priority", "Escalation Level (Priority)"))

    return f"""
          <!-- Hero strip: title + status chips -->
          <div class="bg-white border border-gray-200 rounded-DEFAULT shadow-sm px-5 py-4 mb-sm relative overflow-hidden">
            <div class="absolute inset-y-0 left-0 w-1 bg-primary"></div>
            <p class="font-label-sm text-[10px] text-secondary uppercase tracking-wider mb-1">Order Title</p>
            <p class="text-[17px] font-bold text-on-surface font-mono leading-snug break-words" data-bsp="order_title">-</p>
            <p class="text-[12px] text-secondary mt-1 break-words" data-bsp="short_description"></p>
            <div class="flex flex-wrap gap-2 mt-3">
              <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-[10px] uppercase font-bold tracking-wider">
                Type: <span data-bsp="order_type">-</span>
              </span>
              <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-[10px] uppercase font-bold tracking-wider">
                Category: <span data-bsp="order_category">-</span>
              </span>
              <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-[10px] uppercase font-bold tracking-wider">
                Status: <span data-bsp="status">-</span>
              </span>
            </div>
          </div>

          <!-- Sections grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-sm mb-sm">
            {_section("General", "info", general)}
            {_section("Parties &amp; Billing", "account_balance", parties)}
            {_section("Contacts", "contacts", contacts)}
            {_section("Dates &amp; References", "event_note", dates_refs)}
          </div>

          <!-- Description: full width -->
          <section class="bg-white border border-gray-200 rounded-DEFAULT shadow-sm overflow-hidden">
            <div class="bg-gray-50 px-4 py-2 flex items-center gap-2 border-b border-gray-200">
              <span class="material-symbols-outlined text-primary text-[16px]">description</span>
              <h3 class="text-[11px] uppercase tracking-wider text-gray-600 font-bold" style="font-family:'JetBrains Mono',monospace;">Description</h3>
            </div>
            <p class="px-5 py-4 text-[13px] text-on-surface leading-relaxed whitespace-pre-wrap break-words" data-bsp="description">-</p>
          </section>"""


def view() -> str:
    return """
    <div id="view-results" class="bg-background text-on-surface flex-grow" style="display:none; flex-direction:column; min-height:0;">
      <main class="max-w-7xl mx-auto w-full pt-6 px-6 py-6 flex flex-col flex-grow min-h-0">
        <div class="w-full flex-grow flex flex-col min-h-0">
          <div class="mb-md flex justify-between items-end border-b border-outline/10 pb-2">
            <div>
              <h1 class="text-[22px] font-bold text-on-surface leading-tight">Results</h1>
              <p class="font-body-md text-[13px] text-secondary mt-0.5" id="results-opp-subtitle">Opportunity ID: None</p>
            </div>
            <div class="flex items-center gap-2 pb-1">
              <button onclick="showSection('validation')"
                 class="flex items-center gap-1 px-3 py-1 bg-white border border-gray-300 text-gray-700 text-[11px] rounded hover:bg-gray-50 transition-colors uppercase tracking-wider"
                 style="font-family:'JetBrains Mono',monospace;">
                <span class="material-symbols-outlined text-[14px] mr-0.5">checklist</span> Validation
              </button>
              <button onclick="exportExcel()"
                 class="flex items-center gap-1 px-3 py-1 bg-primary text-white text-[11px] rounded hover:bg-red-700 transition-colors uppercase tracking-wider"
                 style="font-family:'JetBrains Mono',monospace;">
                <span class="material-symbols-outlined text-[14px] mr-0.5">download</span> Export
              </button>
            </div>
          </div>

          <!-- Validation-failure alert (only shown when there are failures) -->
          <div id="results-fail-alert" style="display:none;"
               class="mb-md rounded-lg border-2 border-primary bg-red-50 px-4 py-3 flex items-center justify-between gap-4">
            <div class="flex items-center gap-2">
              <span class="material-symbols-outlined text-primary text-[20px]">error</span>
              <p class="text-[13px] text-gray-800 font-medium" id="results-fail-msg"></p>
            </div>
            <button onclick="openEmailDraft()"
               class="flex items-center gap-1 px-3 py-1.5 bg-primary text-white text-[11px] rounded hover:bg-red-700 transition-colors uppercase tracking-wider shrink-0"
               style="font-family:'JetBrains Mono',monospace;">
              <span class="material-symbols-outlined text-[14px] mr-0.5">mail</span> Draft Email
            </button>
          </div>

          <!-- ── Tabs: Sales Order | Sales Order Rows ─────────────────── -->
          <div class="flex items-end gap-1 border-b border-gray-200 mb-md shrink-0">
            <button id="tabbtn-order" onclick="switchOrderTab('order')"
              class="px-5 py-2 text-[12px] uppercase tracking-wider rounded-t border border-b-0 border-gray-200 bg-sidebar-dark text-white font-bold"
              style="font-family:'JetBrains Mono',monospace;">
              Sales Order
            </button>
            <button id="tabbtn-rows" onclick="switchOrderTab('rows')"
              class="px-5 py-2 text-[12px] uppercase tracking-wider rounded-t border border-b-0 border-gray-200 bg-white text-gray-500 hover:text-gray-800"
              style="font-family:'JetBrains Mono',monospace;">
              Sales Order Rows
            </button>
          </div>

          <!-- hidden stubs so app.py's renderResults never throws -->
          <span id="stat-category" style="display:none;"></span>
          <span id="stat-confidence" style="display:none;"></span>

          <!-- ── Tab 1: Sales Order (BSP header) ──────────────────────── -->
          <div id="tab-order" class="mb-md">""" + _sales_order_panel() + """
          </div>

          <!-- ── Tab 2: Sales Order Rows (line items table) ───────────── -->
          <div id="tab-rows-wrap" style="display:none;">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-sm mb-md shrink-0">
            <div class="bg-surface-container-lowest border border-gray-200 px-md py-2 rounded-DEFAULT">
              <p class="font-label-sm text-[10px] text-secondary uppercase">Total Lines</p>
              <p class="text-[24px] leading-tight font-bold text-gray-800" id="stat-total">0</p>
            </div>
            <div class="bg-surface-container-lowest border border-gray-200 px-md py-2 rounded-DEFAULT border-l-4 border-tertiary">
              <p class="font-label-sm text-[10px] uppercase text-tertiary">Verified</p>
              <p class="text-[24px] text-tertiary leading-tight font-bold" id="stat-verified">0</p>
            </div>
            <div class="bg-surface-container-lowest border border-gray-200 px-md py-2 rounded-DEFAULT border-l-4 border-primary">
              <p class="font-label-sm text-[10px] uppercase text-primary">Review Required</p>
              <p class="text-[24px] text-primary leading-tight font-bold" id="stat-review">0</p>
            </div>
          </div>
          <section id="tab-rows" style="height:420px;"
                   class="bg-surface-container-lowest border border-gray-200 rounded-DEFAULT overflow-hidden flex-col shrink-0 shadow-sm mx-auto w-full">
            <div class="overflow-auto custom-scrollbar flex-grow min-h-0 bg-white">
              <table class="w-full text-left border-collapse">
                <thead class="sticky top-0 z-10">
                  <tr class="bg-gray-50 text-gray-500 border-b border-gray-200">
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 w-16 font-semibold">Line #</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Name</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Producer Code</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Location</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 w-14 font-semibold">Qty</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Price</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Charge Type</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Period</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Fulfilment</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">Confidence</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider border-r border-gray-200 font-semibold">AI Comments</th>
                    <th class="px-md py-3 text-[11px] uppercase tracking-wider font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-outline/10 text-sm font-medium" id="results-tbody"></tbody>
              </table>
            </div>
            <div class="px-md py-3 bg-gray-50 flex justify-between items-center border-t border-gray-200 shrink-0">
              <p class="font-label-sm text-[10px] text-secondary uppercase" id="results-count-label">Showing 0 lines</p>
              <div class="flex gap-2">
                <button class="px-3 py-1 bg-white border border-gray-300 text-[11px] rounded uppercase disabled:opacity-50" disabled>Prev</button>
                <button class="px-3 py-1 bg-white border border-gray-300 text-[11px] rounded uppercase disabled:opacity-50" disabled>Next</button>
              </div>
            </div>
          </section>
          </div>

        </div>
      </main>
    </div>

    <!-- Draft Investigation Email popup -->
    <div id="email-modal"
         style="display:none; position:fixed; inset:0; z-index:100; background:rgba(0,0,0,0.35);
                align-items:center; justify-content:center;">
      <div class="bg-white rounded-2xl shadow-2xl w-[640px] max-w-[92vw] max-h-[85vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <h3 class="text-[18px] font-bold text-gray-800">Draft Investigation Email</h3>
          <button onclick="closeEmailDraft()" class="text-gray-400 hover:text-gray-700">
            <span class="material-symbols-outlined">close</span>
          </button>
        </div>
        <div class="px-6 py-4 overflow-y-auto flex flex-col gap-4">
          <div>
            <label class="text-[11px] uppercase tracking-wider text-gray-500 font-semibold">Subject</label>
            <input id="email-subject" type="text" readonly
                   class="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-[13px] text-gray-800 bg-gray-50" />
          </div>
          <div>
            <label class="text-[11px] uppercase tracking-wider text-gray-500 font-semibold">Body</label>
            <textarea id="email-body" readonly rows="12"
                      class="mt-1 w-full border border-gray-200 rounded-lg px-3 py-2 text-[13px] text-gray-800 bg-gray-50 font-mono leading-relaxed resize-none"></textarea>
          </div>
        </div>
        <div class="flex items-center justify-between px-6 py-4 border-t border-gray-200">
          <button id="email-copy-btn" onclick="copyEmailBody()"
                  class="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-[13px] text-gray-700">
            Copy body text
          </button>
          <button onclick="closeEmailDraft()"
                  class="px-5 py-2 bg-white border border-gray-300 rounded-lg text-[13px] text-gray-700 hover:bg-gray-50">
            Close
          </button>
        </div>
      </div>
    </div>

    <script>
      // ── Sales Order tabs + BSP header rendering ─────────────────────
      function switchOrderTab(which) {
        const orderTab = document.getElementById('tab-order');
        const rowsTab = document.getElementById('tab-rows');
        const rowsWrap = document.getElementById('tab-rows-wrap');
        const orderBtn = document.getElementById('tabbtn-order');
        const rowsBtn = document.getElementById('tabbtn-rows');
        const on = 'bg-sidebar-dark text-white font-bold';
        const off = 'bg-white text-gray-500 hover:text-gray-800';
        if (which === 'order') {
          orderTab.style.display = 'block'; rowsWrap.style.display = 'none';
          orderBtn.className = orderBtn.className.replace(off, on);
          rowsBtn.className = rowsBtn.className.replace(on, off);
        } else {
          orderTab.style.display = 'none'; rowsWrap.style.display = 'block';
          rowsTab.style.display = 'flex';
          rowsBtn.className = rowsBtn.className.replace(off, on);
          orderBtn.className = orderBtn.className.replace(on, off);
        }
      }

      function renderSalesOrderHeader() {
        const order = ((window.RESULT || RESULT || {}).order) || {};
        document.querySelectorAll('[data-bsp]').forEach(el => {
          const v = order[el.getAttribute('data-bsp')];
          const empty = (v === null || v === undefined || v === '' || v === 'Not Specified');
          el.innerText = empty ? 'Not Specified' : String(v);
          el.classList.toggle('text-secondary', empty);
          el.classList.toggle('italic', empty);
        });
      }

      // ── Excel export: Sheet 1 = Sales Order, Sheet 2 = Sales Order Rows ──
      const BSP_EXPORT_FIELDS = [
        ["order_title", "Order Title"], ["order_type", "Order Type"],
        ["order_category", "Order Category"], ["status", "Status"],
        ["contract_signed_date", "Contract Signed Date"], ["customer_contact", "Customer Contact"],
        ["location_count", "Location Count"], ["external_reference_number", "External Reference Number"],
        ["company_code", "Company Code"], ["bill_to_party", "Bill To Party"],
        ["ship_to_party", "Ship To Party"], ["order_date", "Order Date"],
        ["sales_contact", "Sales Contact"], ["account_manager", "Account Manager"],
        ["short_description", "Short Description"], ["escalation_level_priority", "Escalation Level (Priority)"],
        ["customer_required_date", "Customer Required Date"], ["customer_reference", "Customer Reference"],
        ["device_services", "Device Services"], ["description", "Description"]
      ];

      function exportExcelTwoSheets() {
        const result = (window.RESULT || RESULT || {});
        const order = result.order || {};
        const lines = order.line_items || [];

        // Sheet 1: Sales Order (Field | Value)
        const headerAoA = [["Field", "Value"]].concat(
          BSP_EXPORT_FIELDS.map(([k, label]) => [label, (order[k] == null ? "" : String(order[k]))])
        );
        const ws1 = XLSX.utils.aoa_to_sheet(headerAoA);
        ws1['!cols'] = [{ wch: 28 }, { wch: 70 }];

        // Sheet 2: Sales Order Rows
        const rows = lines.map((li, i) => {
          let pc = li.producer_code, nm = li.name;
          if ((!pc || pc === 'Not Specified' || !nm || nm === 'Not Specified') && li.item) {
            const parts = String(li.item).split(' - ');
            if (!pc || pc === 'Not Specified') pc = (parts[0] || '').trim();
            if (!nm || nm === 'Not Specified') nm = (parts.slice(1).join(' - ')).trim();
          }
          return {
            "Line": i + 1, "Producer Code": pc || "", "Name": nm || "",
            "Location": li.location || "", "Quantity": li.quantity || "",
            "Price": li.price || "", "Charge Type": li.charge_type || "",
            "Period": li.recurring_period || "", "Fulfilment": li.fulfilment || "",
            "Confidence": li.confidence || "", "Comments": li.confidence_reason || ""
          };
        });
        const ws2 = XLSX.utils.json_to_sheet(rows.length ? rows : [{"Line":"","Producer Code":"","Name":"","Location":"","Quantity":"","Price":"","Charge Type":"","Period":"","Fulfilment":"","Confidence":"","Comments":""}]);
        ws2['!cols'] = [{wch:6},{wch:20},{wch:34},{wch:24},{wch:9},{wch:12},{wch:12},{wch:14},{wch:14},{wch:12},{wch:40}];

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws1, "Sales Order");
        XLSX.utils.book_append_sheet(wb, ws2, "Sales Order Rows");
        XLSX.writeFile(wb, "Q2O_" + ((typeof OPP !== 'undefined' && OPP) || 'export') + "_sales_order.xlsx");
      }

      // ── Rows table renderer: exact OrderLineItem fields ─────────────
      function renderRowsTable() {
        const order = ((window.RESULT || RESULT || {}).order) || {};
        const lines = order.line_items || [];
        const g = (li, k) => { const v = li[k]; return (v === null || v === undefined || v === '') ? 'Not Specified' : String(v); };
        document.getElementById('results-tbody').innerHTML = lines.map((li, i) => {
          const ful = g(li, 'fulfilment');
          const missing = ful === 'Not Specified';
          // Fulfilment cell: plain (no red background). Show value or a dash.
          const fulCell = `
            <td class="px-md py-2 font-label-sm text-[11px] border-r border-outline/10 font-mono">${missing ? '-' : esc(ful)}</td>`;
          // Only the STATUS badge signals a failure in red - not the whole row.
          const badge = missing ? `
            <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-error-container text-primary rounded-full text-[10px] uppercase font-bold">
              <span class="material-symbols-outlined text-[14px]">priority_high</span> Review</span>` : `
            <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-tertiary/10 text-tertiary rounded-full text-[10px] uppercase font-bold">
              <span class="material-symbols-outlined text-[14px]" style="font-variation-settings:'FILL' 1;">check_circle</span> Verified</span>`;
          // confidence pill (High=green, Medium=amber, Low/None=red) - a legend, not row failure
          let conf = g(li, 'confidence');
          if (conf === 'Not Specified' || !conf) conf = 'None';
          const cl = conf.toLowerCase();
          const confColor = cl === 'high' ? 'bg-tertiary/10 text-tertiary'
                          : cl === 'medium' ? 'bg-amber-100 text-amber-700'
                          : (cl === 'low' || cl === 'none') ? 'bg-error-container text-primary'
                          : 'bg-gray-100 text-gray-500';
          const confCell = `
            <td class="px-md py-2 border-r border-outline/10">
              <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] uppercase font-bold ${confColor}">${esc(conf)}</span></td>`;
          // producer code + name (split from item if not provided separately)
          let pcode = g(li, 'producer_code'), pname = g(li, 'name');
          if ((pcode === 'Not Specified' || pname === 'Not Specified') && li.item) {
            const parts = String(li.item).split(' - ');
            if (pcode === 'Not Specified') pcode = (parts[0] || '').trim() || 'Not Specified';
            if (pname === 'Not Specified') pname = (parts.slice(1).join(' - ')).trim() || 'Not Specified';
          }
          const reason = g(li, 'confidence_reason');
          // Period: for One Off (or Not Applicable), show a dash instead.
          const charge = g(li, 'charge_type');
          let period = g(li, 'recurring_period');
          if (String(charge).toLowerCase().includes('one') || period === 'Not Applicable' || period === 'Not Specified') period = '-';
          return `
          <tr class="hover:bg-gray-50 transition-colors group">
            <td class="px-md py-2 font-label-sm text-[11px] text-secondary border-r border-outline/10">${String(i+1).padStart(3,'0')}</td>
            <td class="px-md py-2 font-semibold border-r border-outline/10">${esc(pname)}</td>
            <td class="px-md py-2 font-mono text-[12px] border-r border-outline/10">${esc(pcode)}</td>
            <td class="px-md py-2 border-r border-outline/10">${esc(g(li,'location'))}</td>
            <td class="px-md py-2 border-r border-outline/10 font-mono">${esc(g(li,'quantity'))}</td>
            <td class="px-md py-2 border-r border-outline/10 font-mono">${esc(g(li,'price'))}</td>
            <td class="px-md py-2 border-r border-outline/10">${esc(charge)}</td>
            <td class="px-md py-2 border-r border-outline/10">${esc(period)}</td>
            ${fulCell}
            ${confCell}
            <td class="px-md py-2 border-r border-outline/10 text-[11px] text-secondary max-w-[220px]">${esc(reason === 'Not Specified' ? '' : reason)}</td>
            <td class="px-md py-2">${badge}</td>
          </tr>`;
        }).join('') || '<tr><td colspan="12" class="px-md py-6 text-center text-secondary text-sm">No order lines extracted. Run the order process first.</td></tr>';
      }

      // (line-item confidence stat removed from view; span kept hidden as a stub)
      // % of line-item fields (across all lines) that are populated.
      function renderLineConfidence() {
        const el = document.getElementById('stat-confidence');
        if (!el) return;
        const lines = (((window.RESULT || RESULT || {}).order) || {}).line_items || [];
        if (!lines.length) { el.innerText = '-'; return; }
        const KEYS = ['quantity','item','sku','location','price','charge_type','recurring_period','fulfilment'];
        let filled = 0, total = 0;
        lines.forEach(li => KEYS.forEach(k => {
          total++;
          const v = li[k];
          if (!(v === null || v === undefined || v === '' || v === 'Not Specified')) filled++;
        }));
        el.innerText = Math.round(100 * filled / total) + '%';
      }

      // Hook into the main controller AFTER it is defined
      // (the controller script runs after this one; DOMContentLoaded runs last).
      window.addEventListener('DOMContentLoaded', function () {
        if (typeof renderResults === 'function') {
          const _origRenderResults = renderResults;
          renderResults = function () {
            _origRenderResults();      // stats, subtitles
            renderRowsTable();         // rebuild tbody with model-exact columns
            renderSalesOrderHeader();
            renderLineConfidence();
            renderFailAlert();         // red alert + Draft Email if failures
            switchOrderTab('order');   // Sales Order first, then rows
          };
        }

        // Show the red validation-failure alert (with the Draft Email button)
        // ONLY when there are validation failures. Otherwise hide it entirely.
        window.renderFailAlert = function () {
          const R = (window.RESULT || RESULT || {});
          const n = Number(R.failed_count || 0);
          const alert = document.getElementById('results-fail-alert');
          const msg = document.getElementById('results-fail-msg');
          if (!alert) return;
          if (n > 0) {
            msg.innerText = 'There ' + (n === 1 ? 'is' : 'are') + ' ' + n + ' validation failure' +
                            (n === 1 ? '' : 's') + '. We recommend drafting an email to the team.';
            alert.style.display = 'flex';
          } else {
            alert.style.display = 'none';
          }
        };
        // Replace the controller's single-sheet export with the 2-sheet one
        exportExcel = exportExcelTwoSheets;

        // ---- Draft Email Summary popup ----
        window.openEmailDraft = function () {
          const R = (window.RESULT || RESULT || {});
          const draft = R.email_draft || {};
          const subject = draft.subject || 'Quote-to-order summary';
          let body = (draft.body || 'No email draft was produced for this run.');
          body = body.split(String.fromCharCode(92) + 'n').join(String.fromCharCode(10));
          document.getElementById('email-subject').value = subject;
          document.getElementById('email-body').value = body;
          document.getElementById('email-modal').style.display = 'flex';
        };
        window.closeEmailDraft = function () {
          document.getElementById('email-modal').style.display = 'none';
        };
        window.copyEmailBody = function () {
          const ta = document.getElementById('email-body');
          ta.select();
          try { document.execCommand('copy'); } catch (e) {}
          if (navigator.clipboard) navigator.clipboard.writeText(ta.value).catch(()=>{});
          const btn = document.getElementById('email-copy-btn');
          btn.innerText = 'Copied!';
          setTimeout(() => { btn.innerText = 'Copy body text'; }, 1500);
        };
      });
    </script>
    """
