"""View 1: Order Entry (ingestion) - exact markup from Q2O_Anonymised.html."""


def view() -> str:
    return """
    <div id="view-ingestion" class="flex-1 flex flex-col p-6 justify-center items-center" style="min-height:calc(100vh - 62px);">
      <main class="max-w-4xl w-full flex-1 flex flex-col justify-center items-center">
        <h1 class="landing-hero-title">
          Quote-to-Order <span class="text-primary font-bold">Drafting Agent</span>
        </h1>
        <p class="landing-hero-sub">
          Retrieves opportunity documents, classifies order types, applies conditional validation rules,
          extracts order lines with field-level evidence, and deterministic product code
          resolution&mdash;preparing findings for human review before back office order creation.
        </p>
        <div class="w-full flex flex-col gap-6 items-center">
          <div class="border border-gray-200 rounded-lg flex flex-col items-center justify-center p-8 bg-white shadow-sm w-full max-w-2xl min-h-[250px]">
            <div class="w-12 h-12 bg-red-50 rounded-xl shadow-sm flex items-center justify-center mb-4">
              <span class="material-icons text-primary text-2xl">description</span>
            </div>
            <h2 class="text-lg font-semibold text-gray-800 text-center mb-4">
              Enter Opportunity ID to begin drafting
            </h2>
            <div class="w-full max-w-sm mb-4">
              <input type="text" id="opportunity-id" oninput="handleOpportunityInput(this)"
                onkeydown="if(event.key === 'Enter' && this.value.trim()) { startProcessing(); }"
                placeholder="Enter Opportunity ID (e.g. OPP-882910)"
                class="w-full px-4 py-2.5 bg-gray-50 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm text-gray-900 font-medium text-center shadow-inner">
            </div>
            <button id="begin-btn" onclick="startProcessing()" disabled
              class="bg-gray-200 text-gray-400 font-medium py-2 px-8 rounded shadow-sm cursor-not-allowed transition-all duration-300 text-xs uppercase tracking-wider"
              style="font-family:'JetBrains Mono',monospace;">
              Begin order creation process
            </button>
          </div>
        </div>
      </main>
    </div>
    """
