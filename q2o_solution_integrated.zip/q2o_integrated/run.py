"""Run the whole Q2O app: agent API (FastAPI) + Streamlit UI, one command.

    python run.py

Env:
    AGENT_API_PORT   default 8000
    UI_PORT          default 8501
    AGENT_MOCK=1     serve sample data instead of calling the real agent
"""

import os
import subprocess
import sys
import threading
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
API_PORT = int(os.getenv("AGENT_API_PORT", "8000"))
UI_PORT = int(os.getenv("UI_PORT", "8501"))

os.environ.setdefault("AGENT_API_URL", f"http://localhost:{API_PORT}")
sys.path.insert(0, ROOT)


def start_api():
    import uvicorn
    from agent_api import app
    uvicorn.run(app, host="0.0.0.0", port=API_PORT, log_level="info")


def main():
    api_thread = threading.Thread(target=start_api, daemon=True)
    api_thread.start()
    time.sleep(1.5)  # give the API a head start

    ui_env = os.environ.copy()
    subprocess.run(
        [sys.executable, "-m", "streamlit", "run",
         os.path.join(ROOT, "ui", "app.py"),
         "--server.port", str(UI_PORT),
         "--server.headless", "true",
         "--browser.gatherUsageStats", "false"],
        cwd=os.path.join(ROOT, "ui"),
        env=ui_env,
        check=False,
    )


if __name__ == "__main__":
    main()
