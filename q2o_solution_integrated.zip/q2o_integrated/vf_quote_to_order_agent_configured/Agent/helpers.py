"""
Legacy helpers.

The old before_agent_callback that loaded Agent/sample.json has been
replaced by the GCS retrieval tool in tools.py
(get_opportunity_data), which is called by the validation agent with
the opportunity id supplied by the user.

Kept as a module so existing imports do not break.
"""
