from pydantic import BaseModel, Field
from typing import Any, List


class OrderLineItem(BaseModel):
    """One product / service line on the BSP order."""

    quantity: Any = Field(
        "Not Specified", description="Quantity ordered for this line."
    )
    item: Any = Field(
        "Not Specified",
        description=(
            "Item name / part code. For CIRCUIT orders, every circuit part "
            "code MUST be accompanied by companion rows: SLA, ECS-INSTALL, "
            "ECS-INTSAndConfigIRL (installation charges, SLA, installation "
            "and engineering)."
        ),
    )
    sku: Any = Field(
        "Not Specified", description="SKU - product stock code."
    )
    location: Any = Field(
        "Not Specified", description="Location / site this line applies to."
    )
    price: Any = Field(
        "Not Specified", description="Sell price for this line."
    )
    charge_type: Any = Field(
        "Not Specified",
        description="'Recurring' or 'One Off'.",
    )
    recurring_period: Any = Field(
        "Not Specified",
        description=(
            "If charge_type is Recurring, the period (e.g. Monthly, "
            "Quarterly, Annually). 'Not Applicable' for One Off charges."
        ),
    )
    fulfilment: Any = Field(
        "Not Specified",
        description=(
            "Fulfilment code from BSP. If not found: H202 for hardware, "
            "J404 for software and licences."
        ),
    )
    confidence: Any = Field(
        "Not Specified",
        description=(
            "Confidence of the resolved product code from the Product Code "
            "Navigator: High, Medium, Low, or None."
        ),
    )
    producer_code: Any = Field(
        "Not Specified",
        description="Resolved producer/stock code (left part of 'code - name').",
    )
    name: Any = Field(
        "Not Specified",
        description="Resolved product name/description (right part of 'code - name').",
    )
    confidence_reason: Any = Field(
        "",
        description="Why the Product Code Navigator assigned this confidence.",
    )


class BSPOrderTemplate(BaseModel):
    """BSP order template filled from the opportunity documents."""

    order_title: Any = Field(
        "Not Specified",
        description=(
            "Order title. For CIRCUIT orders the format is: "
            "<CustomerSegment>_<OrderType>_<VendorName>_<Service>_<Customer> "
            "and it MUST include the customer segment and the Site ID."
        ),
    )
    order_type: Any = Field(
        "New", description="Order type. Always 'New'."
    )
    order_category: Any = Field(
        "Not Specified",
        description=(
            "Major order category: 'Kit' or 'Circuit' (others possible). "
            "Determined from the tech spec / documents. Drives which "
            "validation checks and template rules apply."
        ),
    )
    status: Any = Field(
        "Not Specified", description="Order status."
    )
    contract_signed_date: Any = Field(
        "Not Specified", description="Contract signed date."
    )
    customer_contact: Any = Field(
        "Not Specified", description="Customer contact."
    )
    location_count: Any = Field(
        "Not Specified",
        description="Number of locations, one of: '1', '2-5', '6-10', '11-20', '>20'.",
    )
    external_reference_number: Any = Field(
        "Not Specified", description="External reference number = the opportunity id."
    )
    company_code: Any = Field(
        "Not Specified", description="Company code."
    )
    bill_to_party: Any = Field(
        "Not Specified", description="Bill to party."
    )
    ship_to_party: Any = Field(
        "Not Specified", description="Ship to party."
    )
    order_date: Any = Field(
        "Not Specified",
        description="Order date = the date this template is created (today).",
    )
    sales_contact: Any = Field(
        "Not Specified", description="Sales contact = the submitter's email."
    )
    account_manager: Any = Field(
        "Not Specified", description="Account manager."
    )
    short_description: Any = Field(
        "Not Specified", description="Short description - same as the order title."
    )
    escalation_level_priority: Any = Field(
        "Not Specified", description="Escalation level / priority."
    )
    customer_required_date: Any = Field(
        "Not Specified", description="Customer required date."
    )
    customer_reference: Any = Field(
        "Not Specified",
        description="Customer reference: PO number, or email, or signed PO.",
    )
    description: Any = Field(
        "Not Specified",
        description=(
            "Long description. Must include: sales specialist, contact details "
            "(name, mobile, email), submitter notes, customer delivery address "
            "and Eircode, additional info, and SITE ID (circuit orders ONLY)."
        ),
    )
    device_services: Any = Field(
        "Not Specified",
        description=(
            "Circuit orders: always 'IP VPN - Managed WAN'. "
            "Any other order type: 'System Integration'."
        ),
    )
    line_items: List[OrderLineItem] = Field(
        default_factory=list,
        description="One entry per product/service line on the order.",
    )


## Legacy schema kept for reference / backward compatibility.
class SalesOrderRow(BaseModel):
    id: Any = "Not Specified"
    salesorder_id: Any = "Not Specified"
    item_model_id: Any = "Not Specified"
    location_id: Any = "Not Specified"
    name_on_bill_extra: Any = "Not Specified"
    quantity: Any = "Not Specified"
    group_id: Any = "Not Specified"
    price: Any = "Not Specified"
    discount_percentage: Any = "Not Specified"
    contract_period: Any = "Not Specified"
    contractid: Any = "Not Specified"
    costheading: Any = "Not Specified"
    owner: Any = "Not Specified"
    is_vov: Any = "Not Specified"
    no_invoice: Any = "Not Specified"
    deleted: Any = "Not Specified"
    created_on: Any = "Not Specified"
    created_by: Any = "Not Specified"
    updated_on: Any = "Not Specified"
    updated_by: Any = "Not Specified"
    bss_unify_id: Any = "Not Specified"
    item_id: Any = "Not Specified"
    evo_salesorder_fulfilment_id: Any = "Not Specified"
