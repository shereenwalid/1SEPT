"""
Product Code Navigator agent.

Runs in parallel with the validation agent. Reads the tech spec (already loaded
into shared session state as "opportunity_data" by the retrieval node), and for
every product line resolves the FINAL BSP item code via BigQuery, returning
"code - name/desc" plus a confidence level.

Its output (session state key "resolved_product_codes") is consumed by the BSP
extraction agent to fill each order row's Item and Confidence columns.
"""

# Reuse the same proxy-backed model the root agents use.
try:
    from ...Agent.agent import gemini_model
except Exception:  # noqa: BLE001
    gemini_model = None

from google.adk import Agent

from .tools import resolve_product_code


PRODUCT_CODE_PROMPT = """
You are the Product Code Navigator.

The opportunity's parsed documents are in session state:
{opportunity_data?}

STEP 1 - Find the TECH SPEC document (tech_spec_files: {tech_spec_files?}).
STEP 2 - From the tech spec, list EVERY product/service line. For each one,
         read its PRODUCT STOCK CODE (a.k.a. producer / supplier code) and its
         ITEM (stock) DESCRIPTION. Some lines may have only a description.
STEP 3 - For EACH product line, call the tool `resolve_product_code` with:
           product_stock_code = the code (or "" if none)
           description        = the item description
         Call it once per product line. Do not guess codes yourself.

The tool returns the resolved final code as "code - name/desc" plus a
confidence (High / Medium / Low / None). Use exactly what the tool returns -
never invent or alter a code.

Return ONLY this JSON object (no markdown, no commentary):
{
  "resolved_codes": [
    {
      "product_stock_code": "<what you read from the tech spec, or ''>",
      "description": "<what you read from the tech spec>",
      "resolved": "<code - name/desc, exactly from the tool>",
      "confidence": "High|Medium|Low|None"
    }
  ]
}
"""

product_code_agent = Agent(
    model=gemini_model,
    name="product_code_agent",
    mode="single_turn",
    description="Resolves tech-spec products to final BSP item codes with confidence.",
    instruction=PRODUCT_CODE_PROMPT,
    tools=[resolve_product_code],
    output_key="resolved_product_codes",
)
