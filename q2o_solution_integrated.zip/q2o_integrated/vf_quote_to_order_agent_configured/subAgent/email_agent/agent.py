"""
Summary Email Drafter agent.

Runs at the END of the pipeline (after extraction). It reads everything in
session state - the validation report, the resolved product codes, and the
filled BSP order - and drafts a concise investigation/summary email for the
user. It returns ONLY a subject and a body.

Output (session state key "email_draft"):
    { "subject": "...", "body": "..." }
"""

try:
    from ..Agent.agent import gemini_model
except Exception:  # noqa: BLE001
    gemini_model = None

from google.adk import Agent

try:
    from ..Agent.tools import read_validation_file
except Exception:  # noqa: BLE001
    read_validation_file = None


EMAIL_PROMPT = """
You are a Vodafone quote-to-order assistant that drafts a concise summary
email for the team, based on everything produced in this run.

FIRST, call the tool `read_validation_file` with the opportunity id to load the
validation results (the checks and their pass/fail/reasoning). The opportunity
id is available in state as {opportunity_id?}.

You also have in session state:
- The filled BSP order (header + line items):
{bsp_order?}
- The resolved product codes (with confidence + reasoning):
{resolved_product_codes?}

Write a clear, professional internal email that summarises BOTH:

A) VALIDATION
   - The overall validation status (from validation.json's "validation.status"
     and "report").
   - Each FAILED or WARNING check, with its specific reason (from the report's
     required_information / checks / bsp_base_checks arrays - a row marked "N"
     is a failure; include its comment).

B) ORDER / LINE ITEMS
   - Any pricing variance, quantity/delivery mismatch, or fulfilment gap in the
     order line items.
   - Product code confidence concerns (Low/None confidence rows and why).

Then a short, bulleted list of recommended actions.

Rules:
- Be specific: name the SKU / item / check and the figures where available.
- Keep it tight - a billing/ops person should grasp it in under a minute.
- Neutral, factual tone. If everything passed, say so and state it is ready.

Return ONLY this JSON object (no markdown, no commentary):
{
  "subject": "<a specific subject line, include the opportunity id>",
  "body": "<the full email body as plain text; use \\n for line breaks>"
}
"""

email_agent = Agent(
    model=gemini_model,
    name="email_agent",
    mode="single_turn",
    description="Drafts a summary investigation email (subject + body) from validation + order.",
    instruction=EMAIL_PROMPT,
    tools=[read_validation_file] if read_validation_file else [],
    output_key="email_draft",
)
